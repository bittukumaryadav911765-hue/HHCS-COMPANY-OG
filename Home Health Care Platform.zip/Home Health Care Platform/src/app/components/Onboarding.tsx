import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Home, Shield, Clock, ChevronRight } from 'lucide-react';

export default function Onboarding() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const navigate = useNavigate();

  const slides = [
    {
      title: 'Home Healthcare at Your Doorstep',
      description: 'Professional medical care and assistance delivered right to your home with verified, trusted healthcare providers.',
      icon: Home,
      gradient: 'from-[#0A84FF] to-[#0066CC]'
    },
    {
      title: 'Verified Caretakers & Nurses',
      description: 'All our healthcare professionals are verified, background-checked, and certified to ensure your safety and peace of mind.',
      icon: Shield,
      gradient: 'from-[#34C759] to-[#28A745]'
    },
    {
      title: '24/7 Emergency Support',
      description: 'Round-the-clock availability for emergency situations. Get immediate help whenever you need it, day or night.',
      icon: Clock,
      gradient: 'from-[#FF9500] to-[#FF6B00]'
    }
  ];

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      navigate('/role-selection');
    }
  };

  const handleSkip = () => {
    navigate('/role-selection');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 flex flex-col p-6">
      <div className="flex-1 flex items-center justify-center">
        <div className="max-w-md w-full">
          <div className={`w-32 h-32 bg-gradient-to-br ${slides[currentSlide].gradient} rounded-3xl mx-auto mb-8 flex items-center justify-center shadow-2xl`}>
            {(() => {
              const Icon = slides[currentSlide].icon;
              return <Icon className="w-16 h-16 text-white" strokeWidth={2} />;
            })()}
          </div>

          <h2 className="text-3xl font-bold text-gray-800 text-center mb-4">
            {slides[currentSlide].title}
          </h2>

          <p className="text-gray-600 text-center text-lg leading-relaxed mb-8">
            {slides[currentSlide].description}
          </p>

          <div className="flex justify-center gap-2 mb-12">
            {slides.map((_, index) => (
              <div
                key={index}
                className={`h-2 rounded-full transition-all ${
                  index === currentSlide
                    ? 'w-8 bg-[#0A84FF]'
                    : 'w-2 bg-gray-300'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <button
          onClick={handleNext}
          className="w-full bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white py-4 rounded-2xl font-semibold shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
        >
          {currentSlide < slides.length - 1 ? 'Next' : 'Get Started'}
          <ChevronRight className="w-5 h-5" />
        </button>

        {currentSlide < slides.length - 1 && (
          <button
            onClick={handleSkip}
            className="w-full text-gray-600 py-4 rounded-2xl font-semibold hover:text-[#0A84FF] transition-colors"
          >
            Skip
          </button>
        )}
      </div>
    </div>
  );
}
