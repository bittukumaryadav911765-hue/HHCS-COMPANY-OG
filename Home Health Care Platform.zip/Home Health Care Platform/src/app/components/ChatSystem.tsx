import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Send, Phone, Video, MoreVertical, Paperclip, Smile,
  X, Camera, Mic, CheckCheck
} from 'lucide-react';

export default function ChatSystem() {
  const navigate = useNavigate();
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: 'staff',
      text: 'Hello! I\'m on my way to your location. I should arrive in about 15 minutes.',
      time: '10:45 AM',
      read: true
    },
    {
      id: 2,
      sender: 'user',
      text: 'Great! Thank you for the update. Do you need any specific information?',
      time: '10:46 AM',
      read: true
    },
    {
      id: 3,
      sender: 'staff',
      text: 'No, I have all the details. Please make sure someone is available to open the door.',
      time: '10:47 AM',
      read: true
    },
    {
      id: 4,
      sender: 'user',
      text: 'Sure, I\'ll be waiting. See you soon!',
      time: '10:48 AM',
      read: true
    }
  ]);

  const staff = {
    name: 'Sarah Johnson',
    avatar: '👩‍⚕️',
    status: 'Online',
    service: 'Professional Nurse'
  };

  const handleSend = () => {
    if (message.trim()) {
      const newMessage = {
        id: messages.length + 1,
        sender: 'user',
        text: message,
        time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        read: false
      };
      setMessages([...messages, newMessage]);
      setMessage('');

      setTimeout(() => {
        const reply = {
          id: messages.length + 2,
          sender: 'staff',
          text: 'Thank you for your message. I\'ll respond shortly.',
          time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
          read: false
        };
        setMessages((prev) => [...prev, reply]);
      }, 2000);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-[#F5F7FA]">
      <div className="bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white p-4 shadow-lg">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center text-2xl">
            {staff.avatar}
          </div>

          <div className="flex-1">
            <h2 className="font-bold text-lg">{staff.name}</h2>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              <p className="text-sm text-blue-100">{staff.status}</p>
            </div>
          </div>

          <button className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
            <Phone className="w-5 h-5" />
          </button>
          <button className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
            <Video className="w-5 h-5" />
          </button>
          <button className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <div className="text-center">
          <div className="inline-block bg-white px-4 py-2 rounded-full shadow-sm">
            <p className="text-xs text-gray-500">Today</p>
          </div>
        </div>

        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[75%] ${
                msg.sender === 'user'
                  ? 'bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white'
                  : 'bg-white text-gray-800'
              } rounded-2xl px-4 py-3 shadow-md`}
            >
              <p className="text-sm">{msg.text}</p>
              <div className={`flex items-center gap-1 mt-1 justify-end ${
                msg.sender === 'user' ? 'text-blue-100' : 'text-gray-500'
              }`}>
                <span className="text-xs">{msg.time}</span>
                {msg.sender === 'user' && (
                  <CheckCheck className={`w-4 h-4 ${msg.read ? 'text-blue-200' : 'text-blue-300'}`} />
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white border-t border-gray-200 p-4">
        <div className="flex items-center gap-3">
          <button className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center">
            <Paperclip className="w-5 h-5 text-gray-600" />
          </button>

          <div className="flex-1 relative">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Type a message..."
              className="w-full px-4 py-3 bg-gray-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#0A84FF] pr-12"
            />
            <button className="absolute right-3 top-1/2 -translate-y-1/2">
              <Smile className="w-5 h-5 text-gray-400" />
            </button>
          </div>

          {message.trim() ? (
            <button
              onClick={handleSend}
              className="w-12 h-12 bg-gradient-to-r from-[#0A84FF] to-[#0066CC] rounded-xl flex items-center justify-center shadow-lg"
            >
              <Send className="w-5 h-5 text-white" />
            </button>
          ) : (
            <>
              <button className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center">
                <Camera className="w-5 h-5 text-gray-600" />
              </button>
              <button className="w-10 h-10 bg-gradient-to-r from-[#0A84FF] to-[#0066CC] rounded-xl flex items-center justify-center">
                <Mic className="w-5 h-5 text-white" />
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
