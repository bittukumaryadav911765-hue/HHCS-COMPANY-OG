import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Star, Gift, Trophy, Award, TrendingUp, X, ChevronRight,
  Crown, Zap, Target, Check, Lock
} from 'lucide-react';

export default function RewardsLoyalty() {
  const navigate = useNavigate();

  const userStats = {
    currentPoints: 1250,
    tierLevel: 'Gold',
    nextTierPoints: 2500,
    lifetimePoints: 5600,
    totalSavings: 4500
  };

  const tiers = [
    {
      name: 'Silver',
      minPoints: 0,
      color: 'from-gray-400 to-gray-500',
      icon: Award,
      benefits: ['5% cashback', 'Priority support', 'Birthday bonus'],
      active: false
    },
    {
      name: 'Gold',
      minPoints: 1000,
      color: 'from-yellow-400 to-yellow-600',
      icon: Star,
      benefits: ['10% cashback', '24/7 priority support', 'Free service upgrade', 'Birthday bonus'],
      active: true
    },
    {
      name: 'Platinum',
      minPoints: 2500,
      color: 'from-purple-400 to-purple-600',
      icon: Crown,
      benefits: ['15% cashback', 'VIP support', 'Free service upgrades', 'Exclusive offers', 'Birthday bonus'],
      active: false,
      locked: true
    }
  ];

  const redeemOptions = [
    {
      id: 1,
      title: '₹100 Cashback',
      points: 500,
      discount: 100,
      icon: Gift,
      color: 'from-green-500 to-green-600'
    },
    {
      id: 2,
      title: '₹250 Cashback',
      points: 1000,
      discount: 250,
      icon: Trophy,
      color: 'from-blue-500 to-blue-600'
    },
    {
      id: 3,
      title: '₹500 Cashback',
      points: 1800,
      discount: 500,
      icon: Crown,
      color: 'from-purple-500 to-purple-600',
      popular: true
    },
    {
      id: 4,
      title: 'Free Service',
      points: 2500,
      discount: 1000,
      icon: Zap,
      color: 'from-orange-500 to-red-600'
    }
  ];

  const recentActivity = [
    { id: 1, title: 'Booking completed', points: 150, date: 'May 18, 2026', type: 'earned' },
    { id: 2, title: 'Referral bonus', points: 200, date: 'May 15, 2026', type: 'earned' },
    { id: 3, title: 'Redeemed cashback', points: -500, date: 'May 12, 2026', type: 'redeemed' },
    { id: 4, title: 'Review submitted', points: 50, date: 'May 10, 2026', type: 'earned' }
  ];

  const progress = (userStats.currentPoints / userStats.nextTierPoints) * 100;

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      <div className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white p-6 pb-32">
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center"
          >
            <X className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold">Rewards & Loyalty</h1>
          <div className="w-10" />
        </div>

        <div className="bg-white/20 backdrop-blur-sm rounded-3xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <p className="text-sm text-yellow-100 mb-1">Your Points</p>
              <p className="text-5xl font-bold">{userStats.currentPoints}</p>
            </div>
            <div className={`w-20 h-20 bg-gradient-to-br ${tiers.find(t => t.active)?.color} rounded-2xl flex items-center justify-center shadow-xl`}>
              <Star className="w-10 h-10 text-white" />
            </div>
          </div>

          <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4 mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-yellow-100">Current Tier: {userStats.tierLevel}</span>
              <span className="text-sm text-yellow-100">Next: Platinum</span>
            </div>
            <div className="w-full h-3 bg-white/30 rounded-full overflow-hidden">
              <div
                className="h-full bg-white rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-xs text-yellow-100 mt-2 text-center">
              {userStats.nextTierPoints - userStats.currentPoints} points to Platinum tier
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white/20 backdrop-blur-sm rounded-xl p-3 text-center">
              <p className="text-sm text-yellow-100 mb-1">Lifetime Points</p>
              <p className="text-2xl font-bold">{userStats.lifetimePoints}</p>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-xl p-3 text-center">
              <p className="text-sm text-yellow-100 mb-1">Total Savings</p>
              <p className="text-2xl font-bold">₹{userStats.totalSavings.toLocaleString()}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="px-6 -mt-24 pb-6 space-y-6">
        <div className="bg-white rounded-3xl shadow-xl p-6">
          <h3 className="font-bold text-gray-800 mb-4">Membership Tiers</h3>
          <div className="space-y-3">
            {tiers.map((tier) => {
              const Icon = tier.icon;
              return (
                <div
                  key={tier.name}
                  className={`rounded-2xl p-5 border-2 transition-all ${
                    tier.active
                      ? 'border-yellow-400 bg-gradient-to-br from-yellow-50 to-orange-50'
                      : tier.locked
                      ? 'border-gray-200 bg-gray-50 opacity-75'
                      : 'border-gray-200 bg-white'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className={`w-14 h-14 bg-gradient-to-br ${tier.color} rounded-xl flex items-center justify-center flex-shrink-0`}>
                      {tier.locked ? (
                        <Lock className="w-7 h-7 text-white" />
                      ) : (
                        <Icon className="w-7 h-7 text-white" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-bold text-gray-800 text-lg">{tier.name}</h4>
                        {tier.active && (
                          <span className="bg-green-500 text-white px-2 py-0.5 rounded-full text-xs font-semibold">
                            Current
                          </span>
                        )}
                        {tier.locked && (
                          <span className="bg-gray-400 text-white px-2 py-0.5 rounded-full text-xs font-semibold">
                            Locked
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mb-3">{tier.minPoints}+ points</p>
                      <div className="space-y-1">
                        {tier.benefits.map((benefit, index) => (
                          <div key={index} className="flex items-center gap-2 text-sm text-gray-700">
                            <Check className="w-4 h-4 text-green-500" />
                            <span>{benefit}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-gray-800">Redeem Points</h3>
            <Target className="w-6 h-6 text-[#0A84FF]" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            {redeemOptions.map((option) => {
              const Icon = option.icon;
              const canRedeem = userStats.currentPoints >= option.points;
              return (
                <div
                  key={option.id}
                  className={`relative rounded-2xl p-4 border-2 transition-all ${
                    canRedeem
                      ? 'border-transparent hover:border-[#0A84FF] cursor-pointer'
                      : 'border-gray-200 opacity-50'
                  }`}
                >
                  {option.popular && (
                    <span className="absolute -top-2 -right-2 bg-gradient-to-r from-orange-500 to-red-500 text-white px-2 py-1 rounded-full text-xs font-semibold">
                      Popular
                    </span>
                  )}
                  <div className={`w-12 h-12 bg-gradient-to-br ${option.color} rounded-xl flex items-center justify-center mb-3`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <h4 className="font-bold text-gray-800 mb-1">{option.title}</h4>
                  <p className="text-sm text-gray-600 mb-3">{option.points} points</p>
                  <button
                    disabled={!canRedeem}
                    onClick={() => canRedeem && alert(`Redeem ${option.title}?`)}
                    className={`w-full py-2 rounded-xl font-semibold text-sm ${
                      canRedeem
                        ? 'bg-[#0A84FF] text-white'
                        : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    }`}
                  >
                    {canRedeem ? 'Redeem' : 'Locked'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-md p-6">
          <h3 className="font-bold text-gray-800 mb-4">Earn More Points</h3>
          <div className="space-y-3">
            {[
              { action: 'Complete a booking', points: 150, icon: Target },
              { action: 'Refer a friend', points: 200, icon: Gift },
              { action: 'Write a review', points: 50, icon: Star },
              { action: 'Add health records', points: 30, icon: TrendingUp }
            ].map((item, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gradient-to-br from-blue-50 to-green-50 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-[#0A84FF] to-[#34C759] rounded-xl flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-white" />
                  </div>
                  <span className="font-semibold text-gray-800">{item.action}</span>
                </div>
                <span className="text-[#0A84FF] font-bold">+{item.points}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-md p-6">
          <h3 className="font-bold text-gray-800 mb-4">Recent Activity</h3>
          <div className="space-y-3">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="flex items-center justify-between py-3 border-b border-gray-100">
                <div>
                  <p className="font-semibold text-gray-800">{activity.title}</p>
                  <p className="text-xs text-gray-500">{activity.date}</p>
                </div>
                <span className={`font-bold ${
                  activity.type === 'earned' ? 'text-green-500' : 'text-red-500'
                }`}>
                  {activity.type === 'earned' ? '+' : ''}{activity.points}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
