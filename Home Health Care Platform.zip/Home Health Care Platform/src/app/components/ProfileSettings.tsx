import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  User, Mail, Phone, MapPin, Lock, CreditCard, AlertCircle,
  ChevronRight, Edit, Camera, Shield, Bell, HelpCircle,
  LogOut, X, Heart
} from 'lucide-react';

export default function ProfileSettings() {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState<'profile' | 'settings' | null>(null);

  const user = {
    name: 'John Doe',
    email: 'john.doe@email.com',
    phone: '+91 9876543210',
    address: '123 Green Park, Sector 12, New Delhi - 110016',
    avatar: '👤',
    memberSince: 'January 2026',
    totalBookings: 24,
    emergencyContact: '+91 9876543211'
  };

  const menuItems = [
    {
      section: 'account',
      items: [
        { icon: User, label: 'Edit Profile', path: '/edit-profile', color: 'text-[#0A84FF]' },
        { icon: Lock, label: 'Change Password', path: '/change-password', color: 'text-[#0A84FF]' },
        { icon: CreditCard, label: 'Wallet & Payments', path: '/wallet', color: 'text-[#0A84FF]' },
        { icon: MapPin, label: 'Saved Addresses', path: '/addresses', color: 'text-[#0A84FF]' }
      ]
    },
    {
      section: 'health',
      items: [
        { icon: Activity, label: 'Health Records', path: '/health-records', color: 'text-green-500' },
        { icon: FileText, label: 'Service History', path: '/service-history', color: 'text-blue-500' },
        { icon: Gift, label: 'Rewards & Loyalty', path: '/rewards', color: 'text-yellow-500' }
      ]
    },
    {
      section: 'preferences',
      items: [
        { icon: Bell, label: 'App Settings', path: '/app-settings', color: 'text-[#FF9500]' },
        { icon: Shield, label: 'Privacy & Security', path: '/app-settings', color: 'text-[#34C759]' },
        { icon: AlertCircle, label: 'Emergency Contacts', path: '/emergency-contacts', color: 'text-[#FF3B30]' }
      ]
    },
    {
      section: 'support',
      items: [
        { icon: HelpCircle, label: 'Help & Support', path: '/support', color: 'text-[#AF52DE]' },
        { icon: Heart, label: 'Rate HHCS', action: () => alert('Thank you for your feedback!'), color: 'text-[#FF2D55]' }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      <div className="bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white p-6 pb-32">
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center"
          >
            <X className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold">Profile & Settings</h1>
          <div className="w-10" />
        </div>
      </div>

      <div className="px-6 -mt-24 pb-6 space-y-6">
        <div className="bg-white rounded-3xl shadow-xl p-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="relative">
              <div className="w-20 h-20 bg-gradient-to-br from-[#0A84FF] to-[#0066CC] rounded-2xl flex items-center justify-center text-3xl">
                {user.avatar}
              </div>
              <button className="absolute -bottom-2 -right-2 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center border-2 border-white">
                <Camera className="w-4 h-4 text-[#0A84FF]" />
              </button>
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-bold text-gray-800">{user.name}</h2>
              <p className="text-sm text-gray-600">{user.email}</p>
              <p className="text-xs text-gray-500 mt-1">Member since {user.memberSince}</p>
            </div>
            <button className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center">
              <Edit className="w-5 h-5 text-gray-600" />
            </button>
          </div>

          <div className="grid grid-cols-3 gap-4 p-4 bg-gradient-to-br from-blue-50 to-green-50 rounded-2xl">
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-800">{user.totalBookings}</p>
              <p className="text-xs text-gray-600">Bookings</p>
            </div>
            <div className="text-center border-l border-r border-gray-200">
              <p className="text-2xl font-bold text-gray-800">4.8</p>
              <p className="text-xs text-gray-600">Rating</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-800">₹45K</p>
              <p className="text-xs text-gray-600">Spent</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-md p-6">
          <h3 className="font-bold text-gray-800 mb-4">Personal Information</h3>
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                <Phone className="w-5 h-5 text-[#0A84FF]" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-600">Phone Number</p>
                <p className="font-semibold text-gray-800">{user.phone}</p>
              </div>
              <button className="text-[#0A84FF] text-sm font-semibold">Edit</button>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                <Mail className="w-5 h-5 text-[#0A84FF]" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-600">Email Address</p>
                <p className="font-semibold text-gray-800">{user.email}</p>
              </div>
              <button className="text-[#0A84FF] text-sm font-semibold">Edit</button>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                <MapPin className="w-5 h-5 text-[#0A84FF]" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-600">Default Address</p>
                <p className="font-semibold text-gray-800 text-sm">{user.address}</p>
              </div>
              <button className="text-[#0A84FF] text-sm font-semibold">Edit</button>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-red-50 rounded-xl flex items-center justify-center">
                <AlertCircle className="w-5 h-5 text-[#FF3B30]" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-600">Emergency Contact</p>
                <p className="font-semibold text-gray-800">{user.emergencyContact}</p>
              </div>
              <button className="text-[#0A84FF] text-sm font-semibold">Edit</button>
            </div>
          </div>
        </div>

        {menuItems.map((section, sectionIndex) => (
          <div key={sectionIndex} className="bg-white rounded-3xl shadow-md p-6">
            <h3 className="font-bold text-gray-800 mb-4 capitalize">{section.section}</h3>
            <div className="space-y-2">
              {section.items.map((item, itemIndex) => (
                <button
                  key={itemIndex}
                  onClick={() => {
                    if (item.action) {
                      item.action();
                    } else if (item.path) {
                      navigate(item.path);
                    }
                  }}
                  className="w-full flex items-center gap-4 p-4 rounded-xl hover:bg-gray-50 transition-all"
                >
                  <div className={`w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center ${item.color}`}>
                    <item.icon className="w-5 h-5" />
                  </div>
                  <span className="flex-1 text-left font-semibold text-gray-800">{item.label}</span>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </button>
              ))}
            </div>
          </div>
        ))}

        <div className="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-5">
          <h3 className="font-semibold text-gray-800 mb-2">Need Help?</h3>
          <p className="text-sm text-gray-600 mb-3">
            Contact our support team 24/7 for any assistance
          </p>
          <div className="flex gap-3">
            <button className="flex-1 bg-[#0A84FF] text-white py-3 rounded-xl font-semibold">
              Call Support
            </button>
            <button className="flex-1 bg-white text-[#0A84FF] border-2 border-[#0A84FF] py-3 rounded-xl font-semibold">
              Chat Support
            </button>
          </div>
        </div>

        <button
          onClick={() => {
            if (confirm('Are you sure you want to logout?')) {
              navigate('/login');
            }
          }}
          className="w-full bg-[#FF3B30] text-white py-4 rounded-2xl font-semibold shadow-lg flex items-center justify-center gap-2"
        >
          <LogOut className="w-5 h-5" />
          Logout
        </button>

        <div className="text-center text-gray-500 text-sm py-4">
          <p>HHCS - Home Health Care Service</p>
          <p className="text-xs mt-1 italic">SEVA PARMO DHARMAH</p>
        </div>
      </div>
    </div>
  );
}
