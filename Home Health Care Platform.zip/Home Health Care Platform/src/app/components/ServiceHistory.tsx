import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Calendar, Clock, Star, Download, Share2, Filter,
  CheckCircle, XCircle, AlertCircle, ChevronRight, X,
  TrendingUp, DollarSign, Heart, Stethoscope, Activity
} from 'lucide-react';

export default function ServiceHistory() {
  const navigate = useNavigate();
  const [filter, setFilter] = useState<'all' | 'completed' | 'cancelled'>('all');
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'year'>('month');

  const bookings = [
    {
      id: 'HHCS2026051800234',
      service: 'Professional Nurse',
      staff: {
        name: 'Sarah Johnson',
        avatar: '👩‍⚕️',
        rating: 4.9
      },
      date: 'May 18, 2026',
      time: '10:00 AM - 6:00 PM',
      duration: '8 hours',
      amount: 3450,
      status: 'completed',
      userRating: 5,
      review: 'Excellent service! Very professional and caring.',
      icon: Stethoscope,
      color: 'from-[#0A84FF] to-[#0066CC]'
    },
    {
      id: 'HHCS2026051500123',
      service: 'Caretaker',
      staff: {
        name: 'Michael Brown',
        avatar: '👨‍⚕️',
        rating: 4.8
      },
      date: 'May 15, 2026',
      time: '8:00 AM - 4:00 PM',
      duration: '8 hours',
      amount: 2500,
      status: 'completed',
      userRating: 5,
      review: 'Great experience. Highly recommended!',
      icon: Heart,
      color: 'from-[#34C759] to-[#28A745]'
    },
    {
      id: 'HHCS2026051200089',
      service: 'Doctor Consultation',
      staff: {
        name: 'Dr. Amit Kumar',
        avatar: '👨‍⚕️',
        rating: 4.9
      },
      date: 'May 12, 2026',
      time: '3:00 PM',
      duration: '30 mins',
      amount: 1500,
      status: 'completed',
      userRating: 4,
      review: 'Very knowledgeable doctor.',
      icon: Activity,
      color: 'from-[#AF52DE] to-[#9933CC]'
    },
    {
      id: 'HHCS2026050800045',
      service: 'Physiotherapy',
      staff: {
        name: 'Priya Sharma',
        avatar: '👩‍⚕️',
        rating: 4.7
      },
      date: 'May 8, 2026',
      time: '11:00 AM',
      duration: '1 hour',
      amount: 2000,
      status: 'cancelled',
      cancellationReason: 'Cancelled by user - schedule conflict',
      refundAmount: 2000,
      icon: Activity,
      color: 'from-[#FF9500] to-[#FF6B00]'
    }
  ];

  const stats = {
    totalBookings: 24,
    completedBookings: 21,
    cancelledBookings: 3,
    totalSpent: 45600,
    averageRating: 4.8,
    favoriteService: 'Professional Nurse'
  };

  const filteredBookings = bookings.filter((booking) => {
    if (filter === 'all') return true;
    return booking.status === filter;
  });

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      <div className="bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white p-6">
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center"
          >
            <X className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold">Service History</h1>
          <button className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
            <Download className="w-6 h-6" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4">
            <p className="text-sm text-blue-100 mb-1">Total Bookings</p>
            <p className="text-3xl font-bold">{stats.totalBookings}</p>
          </div>
          <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4">
            <p className="text-sm text-blue-100 mb-1">Total Spent</p>
            <p className="text-3xl font-bold">₹{(stats.totalSpent / 1000).toFixed(1)}K</p>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6 -mt-4">
        <div className="bg-white rounded-3xl shadow-md p-6">
          <h3 className="font-bold text-gray-800 mb-4">Your Statistics</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-3 bg-green-50 rounded-xl">
              <CheckCircle className="w-6 h-6 text-green-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-gray-800">{stats.completedBookings}</p>
              <p className="text-xs text-gray-600">Completed</p>
            </div>
            <div className="text-center p-3 bg-yellow-50 rounded-xl">
              <Star className="w-6 h-6 text-yellow-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-gray-800">{stats.averageRating}</p>
              <p className="text-xs text-gray-600">Avg Rating</p>
            </div>
            <div className="text-center p-3 bg-red-50 rounded-xl">
              <XCircle className="w-6 h-6 text-red-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-gray-800">{stats.cancelledBookings}</p>
              <p className="text-xs text-gray-600">Cancelled</p>
            </div>
          </div>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2">
          {[
            { id: 'all', label: 'All Services' },
            { id: 'completed', label: 'Completed' },
            { id: 'cancelled', label: 'Cancelled' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id as any)}
              className={`px-5 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
                filter === tab.id
                  ? 'bg-[#0A84FF] text-white'
                  : 'bg-white text-gray-700'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="space-y-4">
          {filteredBookings.map((booking) => {
            const Icon = booking.icon;
            return (
              <div key={booking.id} className="bg-white rounded-2xl p-5 shadow-md">
                <div className="flex items-start gap-4 mb-4">
                  <div className={`w-14 h-14 bg-gradient-to-br ${booking.color} rounded-xl flex items-center justify-center`}>
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-bold text-gray-800">{booking.service}</h3>
                        <p className="text-sm text-gray-600">{booking.staff.name}</p>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        booking.status === 'completed'
                          ? 'bg-green-100 text-green-700'
                          : 'bg-red-100 text-red-700'
                      }`}>
                        {booking.status}
                      </span>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-gray-600 mb-2">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        <span>{booking.date}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>{booking.time}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {booking.status === 'completed' && booking.userRating && (
                  <div className="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-xl p-4 mb-3">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="flex gap-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < booking.userRating
                                ? 'text-yellow-500 fill-yellow-500'
                                : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm font-semibold text-gray-700">Your Rating</span>
                    </div>
                    <p className="text-sm text-gray-600 italic">"{booking.review}"</p>
                  </div>
                )}

                {booking.status === 'cancelled' && booking.cancellationReason && (
                  <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-3">
                    <p className="text-sm text-gray-700 mb-1">
                      <strong>Reason:</strong> {booking.cancellationReason}
                    </p>
                    {booking.refundAmount && (
                      <p className="text-sm text-green-600">
                        <strong>Refund:</strong> ₹{booking.refundAmount.toLocaleString()} processed
                      </p>
                    )}
                  </div>
                )}

                <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                  <div>
                    <p className="text-sm text-gray-600">Amount Paid</p>
                    <p className="text-xl font-bold text-gray-800">₹{booking.amount.toLocaleString()}</p>
                  </div>
                  <div className="flex gap-2">
                    <button className="px-4 py-2 bg-gray-100 rounded-xl text-sm font-semibold text-gray-700 flex items-center gap-2">
                      <Download className="w-4 h-4" />
                      Receipt
                    </button>
                    {booking.status === 'completed' && (
                      <button className="px-4 py-2 bg-[#0A84FF] text-white rounded-xl text-sm font-semibold">
                        Book Again
                      </button>
                    )}
                  </div>
                </div>

                <button className="w-full mt-3 text-[#0A84FF] font-semibold text-sm flex items-center justify-center gap-2">
                  View Details
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>

        {filteredBookings.length === 0 && (
          <div className="bg-white rounded-2xl p-12 text-center">
            <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-gray-800 mb-2">No Bookings Found</h3>
            <p className="text-gray-600 mb-6">No services match your current filter</p>
            <button
              onClick={() => setFilter('all')}
              className="bg-[#0A84FF] text-white px-6 py-3 rounded-xl font-semibold"
            >
              Show All Bookings
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
