import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  MapPin, Phone, MessageCircle, Navigation, Clock,
  User, Star, CheckCircle, AlertCircle, X
} from 'lucide-react';

export default function LiveTracking() {
  const navigate = useNavigate();
  const [eta, setEta] = useState(15);
  const [status, setStatus] = useState<'confirmed' | 'on-the-way' | 'arrived' | 'completed'>('on-the-way');

  useEffect(() => {
    const timer = setInterval(() => {
      setEta((prev) => (prev > 0 ? prev - 1 : 0));
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  const statusConfig = {
    confirmed: {
      color: 'bg-blue-500',
      icon: CheckCircle,
      text: 'Booking Confirmed',
      description: 'Professional is preparing for your service'
    },
    'on-the-way': {
      color: 'bg-yellow-500',
      icon: Navigation,
      text: 'On The Way',
      description: 'Professional is heading to your location'
    },
    arrived: {
      color: 'bg-green-500',
      icon: MapPin,
      text: 'Arrived',
      description: 'Professional has reached your location'
    },
    completed: {
      color: 'bg-green-600',
      icon: CheckCircle,
      text: 'Service Completed',
      description: 'Thank you for using HHCS'
    }
  };

  const currentStatus = statusConfig[status];
  const StatusIcon = currentStatus.icon;

  const staff = {
    name: 'Sarah Johnson',
    avatar: '👩‍⚕️',
    rating: 4.9,
    phone: '+91 98765 43210',
    service: 'Professional Nurse',
    location: 'Heading towards Green Park, Sector 12'
  };

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      <div className="bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white p-6 pb-32">
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center"
          >
            <X className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold">Live Tracking</h1>
          <button className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
            <AlertCircle className="w-6 h-6" />
          </button>
        </div>

        <div className="text-center">
          <div className={`w-20 h-20 ${currentStatus.color} rounded-full mx-auto mb-4 flex items-center justify-center`}>
            <StatusIcon className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-2xl font-bold mb-2">{currentStatus.text}</h2>
          <p className="text-blue-100">{currentStatus.description}</p>
        </div>
      </div>

      <div className="px-6 -mt-24 pb-6 space-y-6">
        <div className="bg-white rounded-3xl shadow-xl p-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-[#0A84FF] to-[#0066CC] rounded-2xl flex items-center justify-center text-3xl">
              {staff.avatar}
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-gray-800 text-lg">{staff.name}</h3>
              <p className="text-sm text-gray-600">{staff.service}</p>
              <div className="flex items-center gap-1 mt-1">
                <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                <span className="text-sm font-semibold text-gray-800">{staff.rating}</span>
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <button className="flex-1 bg-[#34C759] text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2">
              <Phone className="w-5 h-5" />
              Call
            </button>
            <button className="flex-1 bg-[#0A84FF] text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2">
              <MessageCircle className="w-5 h-5" />
              Chat
            </button>
          </div>
        </div>

        {status === 'on-the-way' && (
          <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-3xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <Clock className="w-6 h-6 text-[#0A84FF]" />
                <div>
                  <p className="text-sm text-gray-600">Estimated Arrival</p>
                  <p className="text-2xl font-bold text-gray-800">{eta} mins</p>
                </div>
              </div>
              <button className="w-12 h-12 bg-white rounded-xl shadow-md flex items-center justify-center">
                <Navigation className="w-6 h-6 text-[#0A84FF]" />
              </button>
            </div>
          </div>
        )}

        <div className="bg-white rounded-3xl shadow-md p-1">
          <div className="h-80 bg-gradient-to-br from-blue-100 to-green-100 rounded-2xl flex items-center justify-center relative overflow-hidden">
            <div className="absolute inset-0 flex items-center justify-center">
              <MapPin className="w-16 h-16 text-[#0A84FF] animate-bounce" />
            </div>
            <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-sm rounded-2xl p-4">
              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-[#0A84FF]" />
                <div className="flex-1">
                  <p className="text-xs text-gray-600">Current Location</p>
                  <p className="text-sm font-semibold text-gray-800">{staff.location}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-md p-6">
          <h3 className="font-bold text-gray-800 mb-4">Service Timeline</h3>
          <div className="space-y-4">
            {[
              { status: 'Booking Confirmed', time: '10:30 AM', completed: true },
              { status: 'Professional Assigned', time: '10:32 AM', completed: true },
              { status: 'On The Way', time: '10:45 AM', completed: status !== 'confirmed', active: status === 'on-the-way' },
              { status: 'Service Started', time: 'Expected 11:00 AM', completed: status === 'completed' || status === 'arrived' },
              { status: 'Service Completed', time: 'Pending', completed: status === 'completed' }
            ].map((item, index) => (
              <div key={index} className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  item.completed
                    ? 'bg-green-500'
                    : item.active
                    ? 'bg-yellow-500 animate-pulse'
                    : 'bg-gray-200'
                }`}>
                  {item.completed ? (
                    <CheckCircle className="w-5 h-5 text-white" />
                  ) : (
                    <div className="w-3 h-3 bg-white rounded-full" />
                  )}
                </div>
                <div className="flex-1">
                  <p className={`font-semibold ${
                    item.completed || item.active ? 'text-gray-800' : 'text-gray-400'
                  }`}>
                    {item.status}
                  </p>
                  <p className="text-sm text-gray-500">{item.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {status === 'completed' && (
          <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-3xl p-6 border-2 border-green-200">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-green-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Service Completed!</h3>
              <p className="text-gray-600">How was your experience with {staff.name}?</p>
            </div>

            <div className="flex gap-2 justify-center mb-6">
              {[1, 2, 3, 4, 5].map((star) => (
                <button key={star} className="w-12 h-12">
                  <Star className="w-full h-full text-yellow-500 hover:fill-yellow-500 transition-all" />
                </button>
              ))}
            </div>

            <button className="w-full bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white py-4 rounded-2xl font-semibold">
              Submit Review
            </button>
          </div>
        )}

        <div className="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-5">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-1" />
            <div>
              <p className="font-semibold text-gray-800 mb-1">Need Help?</p>
              <p className="text-sm text-gray-600 mb-3">
                Contact our 24/7 support team for any assistance
              </p>
              <button className="text-[#0A84FF] font-semibold text-sm">
                Call Support: +91 9430535047
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
