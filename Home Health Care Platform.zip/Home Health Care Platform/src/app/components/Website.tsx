import { useNavigate } from 'react-router-dom';
import {
  Activity, Heart, Stethoscope, Dumbbell, Bed, Users,
  Shield, Clock, CheckCircle, Star, Phone, Mail, MapPin,
  Menu, X
} from 'lucide-react';
import { useState } from 'react';

export default function Website() {
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const services = [
    { name: 'Caretaker', icon: Heart, description: 'Professional home care assistance' },
    { name: 'Nurse', icon: Stethoscope, description: 'Qualified medical nursing care' },
    { name: 'Doctor', icon: Activity, description: 'Expert medical consultation' },
    { name: 'Physiotherapy', icon: Dumbbell, description: 'Recovery and rehabilitation' },
    { name: 'ICU Setup', icon: Bed, description: 'Complete home ICU facility' },
    { name: 'Elder Care', icon: Users, description: 'Specialized senior care' },
  ];

  const features = [
    { title: 'Verified Staff', description: '100% background-verified professionals', icon: Shield },
    { title: '24/7 Support', description: 'Round-the-clock assistance', icon: Clock },
    { title: 'Secure Payment', description: 'Safe online transactions', icon: CheckCircle },
    { title: 'Top Rated', description: 'Highest customer satisfaction', icon: Star },
  ];

  const testimonials = [
    {
      name: 'Rajesh Kumar',
      rating: 5,
      text: 'Excellent service! The caretaker was professional and caring. Highly recommend HHCS.',
      role: 'Client'
    },
    {
      name: 'Priya Sharma',
      rating: 5,
      text: 'Found the perfect nurse for my mother. The app is easy to use and staff is trustworthy.',
      role: 'Client'
    },
    {
      name: 'Dr. Amit Patel',
      rating: 5,
      text: 'Great platform for doctors to connect with patients. Professional and well-managed.',
      role: 'Doctor'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <header className="sticky top-0 bg-white/95 backdrop-blur-sm shadow-sm z-50">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[#0A84FF] to-[#34C759] rounded-xl flex items-center justify-center">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-800">HHCS</h1>
                <p className="text-xs text-gray-600">Home Health Care</p>
              </div>
            </div>

            <nav className="hidden md:flex items-center gap-8">
              <a href="#home" className="text-gray-700 hover:text-[#0A84FF] font-medium">Home</a>
              <a href="#services" className="text-gray-700 hover:text-[#0A84FF] font-medium">Services</a>
              <a href="#about" className="text-gray-700 hover:text-[#0A84FF] font-medium">About</a>
              <a href="#contact" className="text-gray-700 hover:text-[#0A84FF] font-medium">Contact</a>
              <button
                onClick={() => navigate('/login')}
                className="text-[#0A84FF] font-semibold hover:underline"
              >
                Login
              </button>
              <button
                onClick={() => navigate('/role-selection')}
                className="bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white px-6 py-2 rounded-xl font-semibold shadow-md hover:shadow-lg transition-all"
              >
                Register
              </button>
            </nav>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden"
            >
              {mobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>

          {mobileMenuOpen && (
            <nav className="md:hidden pt-4 pb-2 space-y-3">
              <a href="#home" className="block text-gray-700 hover:text-[#0A84FF] font-medium py-2">Home</a>
              <a href="#services" className="block text-gray-700 hover:text-[#0A84FF] font-medium py-2">Services</a>
              <a href="#about" className="block text-gray-700 hover:text-[#0A84FF] font-medium py-2">About</a>
              <a href="#contact" className="block text-gray-700 hover:text-[#0A84FF] font-medium py-2">Contact</a>
              <button
                onClick={() => navigate('/login')}
                className="block w-full text-left text-[#0A84FF] font-semibold py-2"
              >
                Login
              </button>
              <button
                onClick={() => navigate('/role-selection')}
                className="block w-full bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white px-6 py-2 rounded-xl font-semibold"
              >
                Register
              </button>
            </nav>
          )}
        </div>
      </header>

      <section id="home" className="bg-gradient-to-br from-blue-50 via-white to-green-50 py-20 px-6">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-5xl font-bold text-gray-800 mb-6 leading-tight">
              Professional Healthcare at Your Doorstep
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Trusted caretakers, nurses, and doctors available 24/7 for your home healthcare needs.
            </p>
            <div className="text-sm text-gray-600 italic mb-8">
              <p>SEVA PARMO DHARMAH</p>
              <p>DHARMO RAKSHATI RAKSHATAH</p>
            </div>
            <div className="flex flex-wrap gap-4">
              <button
                onClick={() => navigate('/role-selection')}
                className="bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white px-8 py-4 rounded-2xl font-semibold shadow-lg hover:shadow-xl transition-all"
              >
                Book Now
              </button>
              <button
                onClick={() => navigate('/role-selection')}
                className="bg-white text-[#0A84FF] px-8 py-4 rounded-2xl font-semibold border-2 border-[#0A84FF] hover:bg-blue-50 transition-all"
              >
                Become a Caretaker
              </button>
            </div>
          </div>
          <div className="relative">
            <div className="w-full h-96 bg-gradient-to-br from-[#0A84FF]/10 to-[#34C759]/10 rounded-3xl flex items-center justify-center">
              <div className="text-center">
                <Activity className="w-32 h-32 text-[#0A84FF] mx-auto mb-4" />
                <p className="text-2xl font-bold text-gray-800">Your Health, Our Priority</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="services" className="py-20 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Our Services</h2>
            <p className="text-xl text-gray-600">Comprehensive healthcare solutions for every need</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div
                key={index}
                className="bg-gradient-to-br from-blue-50 to-green-50 rounded-2xl p-8 hover:shadow-xl transition-all cursor-pointer"
              >
                <service.icon className="w-12 h-12 text-[#0A84FF] mb-4" />
                <h3 className="text-xl font-bold text-gray-800 mb-2">{service.name}</h3>
                <p className="text-gray-600">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="why-choose-us" className="py-20 px-6 bg-gradient-to-br from-blue-50 to-green-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Why Choose HHCS?</h2>
            <p className="text-xl text-gray-600">Trust, safety, and quality care guaranteed</p>
          </div>

          <div className="grid md:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <div key={index} className="bg-white rounded-2xl p-6 shadow-md text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-[#0A84FF] to-[#0066CC] rounded-2xl mx-auto mb-4 flex items-center justify-center">
                  <feature.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-bold text-gray-800 mb-2">{feature.title}</h3>
                <p className="text-sm text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="testimonials" className="py-20 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">What Our Users Say</h2>
            <p className="text-xl text-gray-600">Trusted by thousands across the country</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-gradient-to-br from-blue-50 to-green-50 rounded-2xl p-6">
                <div className="flex gap-1 mb-3">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4 italic">"{testimonial.text}"</p>
                <div>
                  <p className="font-bold text-gray-800">{testimonial.name}</p>
                  <p className="text-sm text-gray-600">{testimonial.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="about" className="py-20 px-6 bg-gradient-to-br from-blue-50 to-green-50">
        <div className="max-w-7xl mx-auto">
          <div className="bg-white rounded-3xl p-12 shadow-xl">
            <div className="flex items-center gap-6 mb-8">
              <div className="w-24 h-24 bg-gradient-to-br from-[#0A84FF] to-[#34C759] rounded-3xl flex items-center justify-center text-4xl">
                👨‍💼
              </div>
              <div>
                <h2 className="text-3xl font-bold text-gray-800 mb-2">Bittu Yadav</h2>
                <p className="text-xl text-gray-700">Founder & CEO - HHCS</p>
              </div>
            </div>
            <div className="space-y-4 text-gray-600">
              <p className="text-lg">
                <strong className="text-gray-800">Mission:</strong> Providing trusted healthcare service at home.
              </p>
              <p className="text-lg">
                <strong className="text-gray-800">Vision:</strong> Service, trust, safety, and humanity at the core of everything we do.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section id="contact" className="py-20 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Get in Touch</h2>
            <p className="text-xl text-gray-600">We're here to help you 24/7</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-2xl p-8 text-center">
              <Phone className="w-12 h-12 text-[#0A84FF] mx-auto mb-4" />
              <h3 className="font-bold text-gray-800 mb-2">Phone</h3>
              <p className="text-gray-600">+91 9430535047</p>
            </div>
            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-2xl p-8 text-center">
              <Mail className="w-12 h-12 text-[#0A84FF] mx-auto mb-4" />
              <h3 className="font-bold text-gray-800 mb-2">Email</h3>
              <p className="text-gray-600 text-sm">bittukumaryadav911765@gmail.com</p>
            </div>
            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-2xl p-8 text-center">
              <MapPin className="w-12 h-12 text-[#0A84FF] mx-auto mb-4" />
              <h3 className="font-bold text-gray-800 mb-2">Emergency Support</h3>
              <p className="text-gray-600">24/7 Available</p>
            </div>
          </div>
        </div>
      </section>

      <footer className="bg-gray-900 text-white py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-[#0A84FF] to-[#34C759] rounded-xl flex items-center justify-center">
                  <Activity className="w-5 h-5 text-white" />
                </div>
                <h3 className="font-bold text-xl">HHCS</h3>
              </div>
              <p className="text-gray-400 text-sm">
                Professional home healthcare services you can trust.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Services</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Caretaker</li>
                <li>Nurse</li>
                <li>Doctor</li>
                <li>Physiotherapy</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>About Us</li>
                <li>Contact</li>
                <li>Careers</li>
                <li>Blog</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Privacy Policy</li>
                <li>Terms & Conditions</li>
                <li>Cookie Policy</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400 text-sm">
            <p>© 2026 HHCS - Home Health Care Service. All rights reserved.</p>
            <p className="mt-2 italic">SEVA PARMO DHARMAH | DHARMO RAKSHATI RAKSHATAH</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
