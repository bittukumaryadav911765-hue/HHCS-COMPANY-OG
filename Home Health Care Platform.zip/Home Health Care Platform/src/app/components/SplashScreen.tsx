import { useState, useEffect } from 'react';
import { Activity, Shield, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function SplashScreen() {
  const navigate = useNavigate();
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setTimeout(() => setIsLoaded(true), 500);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 flex flex-col items-center justify-center p-6">
      <div className={`text-center space-y-8 max-w-md transition-all duration-700 ${
        isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      }`}>
        <div className="space-y-4">
          <div className="w-24 h-24 bg-gradient-to-br from-[#0A84FF] to-[#34C759] rounded-3xl mx-auto flex items-center justify-center shadow-xl animate-pulse">
            <Activity className="w-12 h-12 text-white" strokeWidth={2.5} />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-[#0A84FF] to-[#34C759] bg-clip-text text-transparent">
            HHCS
          </h1>
          <p className="text-lg text-gray-700 font-medium">
            HOME HEALTH CARE SERVICE
          </p>
          <div className="text-sm text-gray-600 italic space-y-1">
            <p>SEVA PARMO DHARMAH</p>
            <p>DHARMO RAKSHATI RAKSHATAH</p>
          </div>
        </div>

        <div className="space-y-3">
          <button
            onClick={() => navigate('/login')}
            className="w-full bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white py-4 rounded-2xl font-semibold shadow-lg hover:shadow-xl hover:scale-105 transition-all"
          >
            Login
          </button>
          <button
            onClick={() => navigate('/role-selection')}
            className="w-full bg-white text-[#0A84FF] py-4 rounded-2xl font-semibold border-2 border-[#0A84FF] hover:bg-blue-50 hover:scale-105 transition-all"
          >
            Register
          </button>
        </div>

        <div className="flex items-center justify-center gap-6 text-sm text-gray-600">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-[#0A84FF]" />
            <span>Secure</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-[#34C759]" />
            <span>Verified</span>
          </div>
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#0A84FF]" />
            <span>Trusted</span>
          </div>
        </div>
      </div>
    </div>
  );
}
