import { useState } from 'react';
import {
  Home, DollarSign, User, Bell, Clock, MapPin, CheckCircle, X,
  Phone, MessageCircle, Navigation, Star, TrendingUp
} from 'lucide-react';

export default function CaretakerDashboard() {
  const [activeTab, setActiveTab] = useState('home');
  const [status, setStatus] = useState<'available' | 'busy' | 'offline'>('available');

  const dutyRequests = [
    {
      id: 1,
      client: 'Mrs. Johnson',
      service: 'Elder Care',
      location: '123 Main St, Downtown',
      duration: '8 hours',
      payment: '₹2,500',
      time: '2:00 PM - 10:00 PM',
      distance: '2.5 km'
    },
    {
      id: 2,
      client: 'Mr. Smith',
      service: 'Patient Care',
      location: '456 Oak Ave, Uptown',
      duration: '12 hours',
      payment: '₹3,800',
      time: '8:00 AM - 8:00 PM',
      distance: '4.1 km'
    }
  ];

  const earnings = {
    today: '₹2,500',
    week: '₹18,000',
    month: '₹75,000',
    available: '₹62,000'
  };

  return (
    <div className="min-h-screen bg-[#F5F7FA] pb-20">
      {activeTab === 'home' && (
        <div className="p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-800">Welcome, Caretaker!</h1>
              <p className="text-gray-600">Ready to serve today</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-[#34C759] to-[#28A745] rounded-2xl flex items-center justify-center shadow-lg text-2xl">
              👨‍⚕️
            </div>
          </div>

          <div className="bg-white rounded-3xl p-6 shadow-md">
            <p className="text-sm text-gray-600 mb-3">Your Status</p>
            <div className="flex gap-3">
              {(['available', 'busy', 'offline'] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => setStatus(s)}
                  className={`flex-1 py-3 rounded-xl font-semibold capitalize transition-all ${
                    status === s
                      ? s === 'available'
                        ? 'bg-[#34C759] text-white'
                        : s === 'busy'
                        ? 'bg-[#FF9500] text-white'
                        : 'bg-gray-600 text-white'
                      : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-[#34C759] to-[#28A745] rounded-2xl p-5 text-white shadow-lg">
              <DollarSign className="w-8 h-8 mb-2" />
              <p className="text-sm opacity-90">Today's Earnings</p>
              <p className="text-2xl font-bold">{earnings.today}</p>
            </div>
            <div className="bg-gradient-to-br from-[#0A84FF] to-[#0066CC] rounded-2xl p-5 text-white shadow-lg">
              <TrendingUp className="w-8 h-8 mb-2" />
              <p className="text-sm opacity-90">This Week</p>
              <p className="text-2xl font-bold">{earnings.week}</p>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-gray-800">Duty Requests</h2>
              <span className="bg-[#FF3B30] text-white px-3 py-1 rounded-full text-sm font-semibold">
                {dutyRequests.length} New
              </span>
            </div>
            <div className="space-y-4">
              {dutyRequests.map((request) => (
                <div key={request.id} className="bg-white rounded-2xl p-5 shadow-md">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-bold text-gray-800 text-lg">{request.client}</h3>
                      <p className="text-sm text-gray-600">{request.service}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[#34C759] font-bold text-lg">{request.payment}</p>
                      <p className="text-xs text-gray-500">{request.duration}</p>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="w-4 h-4 text-[#0A84FF]" />
                      <span>{request.location}</span>
                      <span className="ml-auto text-xs bg-blue-100 text-[#0A84FF] px-2 py-1 rounded-full">
                        {request.distance}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4 text-[#0A84FF]" />
                      <span>{request.time}</span>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <button className="flex-1 bg-gradient-to-r from-[#34C759] to-[#28A745] text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2">
                      <CheckCircle className="w-5 h-5" />
                      Accept
                    </button>
                    <button className="px-4 bg-gray-100 rounded-xl">
                      <X className="w-5 h-5 text-gray-600" />
                    </button>
                    <button className="px-4 bg-[#0A84FF] rounded-xl">
                      <Navigation className="w-5 h-5 text-white" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl p-5 shadow-md">
            <h3 className="font-bold text-gray-800 mb-4">Current Assignment</h3>
            <div className="flex items-center gap-4 mb-4">
              <div className="w-14 h-14 bg-gradient-to-br from-[#0A84FF] to-[#0066CC] rounded-xl flex items-center justify-center text-2xl">
                👵
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-gray-800">Mrs. Anderson</h4>
                <p className="text-sm text-gray-600">Elder Care - 6 hours remaining</p>
              </div>
              <div className="flex gap-2">
                <button className="w-10 h-10 bg-[#34C759] rounded-xl flex items-center justify-center">
                  <Phone className="w-5 h-5 text-white" />
                </button>
                <button className="w-10 h-10 bg-[#0A84FF] rounded-xl flex items-center justify-center">
                  <MessageCircle className="w-5 h-5 text-white" />
                </button>
              </div>
            </div>
            <button className="w-full bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white py-3 rounded-xl font-semibold">
              Mark Attendance
            </button>
          </div>
        </div>
      )}

      {activeTab === 'earnings' && (
        <div className="p-6 space-y-6">
          <h1 className="text-2xl font-bold text-gray-800 mb-6">Earnings</h1>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white rounded-2xl p-5 shadow-md">
              <p className="text-sm text-gray-600 mb-1">Today</p>
              <p className="text-2xl font-bold text-gray-800">{earnings.today}</p>
            </div>
            <div className="bg-white rounded-2xl p-5 shadow-md">
              <p className="text-sm text-gray-600 mb-1">This Week</p>
              <p className="text-2xl font-bold text-gray-800">{earnings.week}</p>
            </div>
            <div className="bg-white rounded-2xl p-5 shadow-md">
              <p className="text-sm text-gray-600 mb-1">This Month</p>
              <p className="text-2xl font-bold text-gray-800">{earnings.month}</p>
            </div>
            <div className="bg-gradient-to-br from-[#34C759] to-[#28A745] rounded-2xl p-5 text-white shadow-md">
              <p className="text-sm opacity-90 mb-1">Available</p>
              <p className="text-2xl font-bold">{earnings.available}</p>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-md">
            <h3 className="font-bold text-gray-800 mb-4">Withdrawal</h3>
            <p className="text-gray-600 mb-4">
              Withdraw your earnings to your bank account or UPI
            </p>
            <button className="w-full bg-gradient-to-r from-[#34C759] to-[#28A745] text-white py-4 rounded-xl font-semibold shadow-lg">
              Withdraw {earnings.available}
            </button>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-md">
            <h3 className="font-bold text-gray-800 mb-4">Transaction History</h3>
            <div className="space-y-3">
              {[
                { date: 'May 18, 2026', amount: '₹2,500', client: 'Mrs. Johnson', status: 'completed' },
                { date: 'May 17, 2026', amount: '₹3,200', client: 'Mr. Smith', status: 'completed' },
                { date: 'May 16, 2026', amount: '₹1,800', client: 'Ms. Davis', status: 'completed' },
              ].map((txn, index) => (
                <div key={index} className="flex items-center justify-between py-3 border-b border-gray-100">
                  <div>
                    <p className="font-semibold text-gray-800">{txn.client}</p>
                    <p className="text-sm text-gray-500">{txn.date}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-[#34C759]">{txn.amount}</p>
                    <p className="text-xs text-gray-500 capitalize">{txn.status}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'profile' && (
        <div className="p-6 space-y-6">
          <div className="bg-white rounded-2xl p-6 shadow-md">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-20 h-20 bg-gradient-to-br from-[#34C759] to-[#28A745] rounded-2xl flex items-center justify-center text-3xl">
                👨‍⚕️
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-800">Michael Brown</h2>
                <p className="text-gray-600">Professional Caretaker</p>
                <div className="flex items-center gap-1 mt-1">
                  <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                  <span className="font-semibold text-gray-800">4.9</span>
                  <span className="text-gray-500 text-sm">(128 reviews)</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 p-4 bg-gray-50 rounded-xl">
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-800">156</p>
                <p className="text-xs text-gray-600">Jobs Done</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-800">98%</p>
                <p className="text-xs text-gray-600">Success Rate</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-800">4.9</p>
                <p className="text-xs text-gray-600">Rating</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-md">
            <h3 className="font-bold text-gray-800 mb-4">Documents</h3>
            <div className="space-y-3">
              {[
                { name: '10th Certificate', status: 'verified' },
                { name: 'Aadhaar Card', status: 'verified' },
                { name: 'Bank Details', status: 'verified' },
              ].map((doc, index) => (
                <div key={index} className="flex items-center justify-between py-3 border-b border-gray-100">
                  <span className="text-gray-800">{doc.name}</span>
                  <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-semibold">
                    {doc.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-4">
        <div className="flex items-center justify-around max-w-md mx-auto">
          {[
            { id: 'home', icon: Home, label: 'Home' },
            { id: 'earnings', icon: DollarSign, label: 'Earnings' },
            { id: 'notifications', icon: Bell, label: 'Alerts' },
            { id: 'profile', icon: User, label: 'Profile' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center gap-1 ${
                activeTab === tab.id ? 'text-[#34C759]' : 'text-gray-400'
              }`}
            >
              <tab.icon className="w-6 h-6" />
              <span className="text-xs">{tab.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
