import { useNavigate } from 'react-router-dom';
import { CheckCircle, Calendar, Clock, MapPin, User, Download, Share2, Home } from 'lucide-react';

export default function BookingConfirmation() {
  const navigate = useNavigate();

  const booking = {
    id: 'HHCS2026051900123',
    service: 'Professional Nurse',
    staff: {
      name: 'Sarah Johnson',
      avatar: '👩‍⚕️',
      phone: '+91 98765 43210'
    },
    date: 'May 20, 2026',
    time: '10:00 AM',
    duration: '8 hours',
    location: '123 Green Park, Sector 12, New Delhi - 110016',
    amount: '₹3,450',
    paymentMethod: 'UPI'
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 p-6">
      <div className="max-w-2xl mx-auto py-8">
        <div className="text-center mb-8">
          <div className="w-24 h-24 bg-gradient-to-br from-[#34C759] to-[#28A745] rounded-full mx-auto mb-6 flex items-center justify-center shadow-2xl">
            <CheckCircle className="w-12 h-12 text-white" strokeWidth={3} />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Booking Confirmed!</h1>
          <p className="text-gray-600 text-lg">Your healthcare service has been successfully booked</p>
        </div>

        <div className="bg-white rounded-3xl shadow-xl p-8 mb-6">
          <div className="flex items-center justify-between mb-6 pb-6 border-b border-gray-100">
            <div>
              <p className="text-sm text-gray-600 mb-1">Booking ID</p>
              <p className="font-bold text-gray-800">{booking.id}</p>
            </div>
            <div className="flex gap-2">
              <button className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center">
                <Download className="w-5 h-5 text-gray-600" />
              </button>
              <button className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center">
                <Share2 className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-2xl p-6 mb-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-[#0A84FF] to-[#0066CC] rounded-2xl flex items-center justify-center text-3xl">
                {booking.staff.avatar}
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-gray-800 text-lg">{booking.staff.name}</h3>
                <p className="text-sm text-gray-600">{booking.service}</p>
                <p className="text-xs text-gray-500 mt-1">{booking.staff.phone}</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center flex-shrink-0">
                <Calendar className="w-5 h-5 text-[#0A84FF]" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-600">Date</p>
                <p className="font-semibold text-gray-800">{booking.date}</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center flex-shrink-0">
                <Clock className="w-5 h-5 text-[#0A84FF]" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-600">Time & Duration</p>
                <p className="font-semibold text-gray-800">{booking.time} ({booking.duration})</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center flex-shrink-0">
                <MapPin className="w-5 h-5 text-[#0A84FF]" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-600">Service Location</p>
                <p className="font-semibold text-gray-800">{booking.location}</p>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-gray-100">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-600">Total Amount Paid</span>
              <span className="text-2xl font-bold text-[#34C759]">{booking.amount}</span>
            </div>
            <p className="text-sm text-gray-500">Paid via {booking.paymentMethod}</p>
          </div>
        </div>

        <div className="bg-gradient-to-r from-[#0A84FF] to-[#0066CC] rounded-3xl p-6 text-white mb-6">
          <h3 className="font-bold text-lg mb-3">What's Next?</h3>
          <ul className="space-y-3 text-sm">
            <li className="flex items-start gap-3">
              <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-xs">1</span>
              </div>
              <span>You'll receive a confirmation SMS and email shortly</span>
            </li>
            <li className="flex items-start gap-3">
              <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-xs">2</span>
              </div>
              <span>Professional will contact you 30 minutes before arrival</span>
            </li>
            <li className="flex items-start gap-3">
              <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-xs">3</span>
              </div>
              <span>Track their live location on the day of service</span>
            </li>
            <li className="flex items-start gap-3">
              <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-xs">4</span>
              </div>
              <span>Rate your experience after service completion</span>
            </li>
          </ul>
        </div>

        <div className="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-5 mb-6">
          <h3 className="font-semibold text-gray-800 mb-2">Cancellation Policy</h3>
          <p className="text-sm text-gray-600">
            Free cancellation up to 2 hours before scheduled time. After that, cancellation charges may apply.
          </p>
        </div>

        <div className="space-y-3">
          <button
            onClick={() => navigate('/live-tracking')}
            className="w-full bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white py-4 rounded-2xl font-semibold shadow-lg"
          >
            Track Booking
          </button>
          <button
            onClick={() => navigate('/chat')}
            className="w-full bg-white text-[#0A84FF] py-4 rounded-2xl font-semibold border-2 border-[#0A84FF]"
          >
            Chat with Professional
          </button>
          <button
            onClick={() => navigate('/client-dashboard')}
            className="w-full bg-gray-100 text-gray-700 py-4 rounded-2xl font-semibold flex items-center justify-center gap-2"
          >
            <Home className="w-5 h-5" />
            Back to Dashboard
          </button>
        </div>

        <div className="text-center mt-8">
          <p className="text-gray-600 text-sm">
            Need help? Contact support at{' '}
            <a href="tel:+919430535047" className="text-[#0A84FF] font-semibold">
              +91 9430535047
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
