import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Wallet, Plus, TrendingDown, TrendingUp, CreditCard,
  ArrowUpRight, ArrowDownLeft, Calendar, Filter, X,
  Download, Share2, DollarSign, Gift, Star
} from 'lucide-react';

export default function WalletPayments() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'wallet' | 'transactions'>('wallet');

  const walletBalance = 2500;
  const cashback = 450;
  const rewardPoints = 1250;

  const transactions = [
    {
      id: 1,
      type: 'debit',
      title: 'Nurse Service Payment',
      description: 'Booking #HHCS2026051800234',
      amount: 3450,
      date: 'May 18, 2026',
      time: '10:30 AM',
      icon: ArrowUpRight,
      color: 'text-red-500',
      bgColor: 'bg-red-50'
    },
    {
      id: 2,
      type: 'credit',
      title: 'Cashback Received',
      description: 'From previous booking',
      amount: 150,
      date: 'May 18, 2026',
      time: '10:31 AM',
      icon: ArrowDownLeft,
      color: 'text-green-500',
      bgColor: 'bg-green-50'
    },
    {
      id: 3,
      type: 'debit',
      title: 'Caretaker Service',
      description: 'Booking #HHCS2026051500123',
      amount: 2500,
      date: 'May 15, 2026',
      time: '8:00 AM',
      icon: ArrowUpRight,
      color: 'text-red-500',
      bgColor: 'bg-red-50'
    },
    {
      id: 4,
      type: 'credit',
      title: 'Wallet Top-up',
      description: 'Via UPI',
      amount: 5000,
      date: 'May 14, 2026',
      time: '3:45 PM',
      icon: ArrowDownLeft,
      color: 'text-green-500',
      bgColor: 'bg-green-50'
    },
    {
      id: 5,
      type: 'credit',
      title: 'Referral Bonus',
      description: 'Friend joined HHCS',
      amount: 200,
      date: 'May 10, 2026',
      time: '2:15 PM',
      icon: Gift,
      color: 'text-purple-500',
      bgColor: 'bg-purple-50'
    }
  ];

  const paymentMethods = [
    { id: 1, type: 'UPI', name: 'Google Pay', number: 'john@oksbi', primary: true },
    { id: 2, type: 'Card', name: 'HDFC Credit Card', number: '**** 4567', primary: false },
    { id: 3, type: 'UPI', name: 'PhonePe', number: '9876543210@ybl', primary: false }
  ];

  const totalSpent = transactions
    .filter(t => t.type === 'debit')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalReceived = transactions
    .filter(t => t.type === 'credit')
    .reduce((sum, t) => sum + t.amount, 0);

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      <div className="bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white p-6 pb-32">
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center"
          >
            <X className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold">Wallet & Payments</h1>
          <button className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
            <Download className="w-6 h-6" />
          </button>
        </div>

        <div className="bg-white/20 backdrop-blur-sm rounded-3xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm text-blue-100 mb-1">Available Balance</p>
              <p className="text-4xl font-bold">₹{walletBalance.toLocaleString()}</p>
            </div>
            <Wallet className="w-12 h-12" />
          </div>
          <button
            onClick={() => alert('Add money to wallet')}
            className="w-full bg-white text-[#0A84FF] py-3 rounded-xl font-semibold flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add Money
          </button>
        </div>
      </div>

      <div className="px-6 -mt-24 pb-6 space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl p-5 text-white shadow-lg">
            <Gift className="w-8 h-8 mb-2" />
            <p className="text-sm opacity-90">Cashback</p>
            <p className="text-2xl font-bold">₹{cashback}</p>
          </div>
          <div className="bg-gradient-to-br from-yellow-500 to-orange-500 rounded-2xl p-5 text-white shadow-lg">
            <Star className="w-8 h-8 mb-2" />
            <p className="text-sm opacity-90">Reward Points</p>
            <p className="text-2xl font-bold">{rewardPoints}</p>
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-md p-6">
          <h3 className="font-bold text-gray-800 mb-4">This Month</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-red-50 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingDown className="w-5 h-5 text-red-500" />
                <span className="text-sm text-gray-600">Spent</span>
              </div>
              <p className="text-2xl font-bold text-gray-800">₹{totalSpent.toLocaleString()}</p>
            </div>
            <div className="bg-green-50 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-5 h-5 text-green-500" />
                <span className="text-sm text-gray-600">Received</span>
              </div>
              <p className="text-2xl font-bold text-gray-800">₹{totalReceived.toLocaleString()}</p>
            </div>
          </div>
        </div>

        <div className="flex gap-2">
          {[
            { id: 'wallet', label: 'Wallet', icon: Wallet },
            { id: 'transactions', label: 'Transactions', icon: Calendar }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-semibold transition-all ${
                activeTab === tab.id
                  ? 'bg-[#0A84FF] text-white'
                  : 'bg-white text-gray-700'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              {tab.label}
            </button>
          ))}
        </div>

        {activeTab === 'wallet' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl p-6 shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-gray-800">Payment Methods</h3>
                <button className="text-[#0A84FF] font-semibold text-sm flex items-center gap-1">
                  <Plus className="w-4 h-4" />
                  Add New
                </button>
              </div>
              <div className="space-y-3">
                {paymentMethods.map((method) => (
                  <div
                    key={method.id}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      method.primary
                        ? 'border-[#0A84FF] bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-[#0A84FF] to-[#0066CC] rounded-xl flex items-center justify-center">
                          <CreditCard className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <p className="font-semibold text-gray-800">{method.name}</p>
                          <p className="text-sm text-gray-600">{method.number}</p>
                        </div>
                      </div>
                      {method.primary && (
                        <span className="bg-[#0A84FF] text-white px-3 py-1 rounded-full text-xs font-semibold">
                          Primary
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200 rounded-2xl p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                  <Gift className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-gray-800 mb-2">Refer & Earn</h3>
                  <p className="text-sm text-gray-600 mb-4">
                    Invite friends and get ₹200 cashback when they complete their first booking!
                  </p>
                  <button className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-xl font-semibold flex items-center gap-2">
                    <Share2 className="w-5 h-5" />
                    Share Referral Link
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'transactions' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-gray-800">Recent Transactions</h3>
              <button className="text-[#0A84FF] font-semibold text-sm flex items-center gap-2">
                <Filter className="w-4 h-4" />
                Filter
              </button>
            </div>

            {transactions.map((transaction) => {
              const Icon = transaction.icon;
              return (
                <div key={transaction.id} className="bg-white rounded-2xl p-5 shadow-md">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 ${transaction.bgColor} rounded-xl flex items-center justify-center`}>
                      <Icon className={`w-6 h-6 ${transaction.color}`} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-800">{transaction.title}</h4>
                      <p className="text-sm text-gray-600">{transaction.description}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {transaction.date} • {transaction.time}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className={`text-xl font-bold ${transaction.color}`}>
                        {transaction.type === 'debit' ? '-' : '+'}₹{transaction.amount.toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}

            <button className="w-full text-[#0A84FF] font-semibold py-3">
              Load More Transactions
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
