import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Bell, Globe, Moon, Volume2, Shield, Database,
  ChevronRight, X, Check
} from 'lucide-react';

export default function AppSettings() {
  const navigate = useNavigate();
  const [settings, setSettings] = useState({
    notifications: {
      bookings: true,
      messages: true,
      offers: true,
      reminders: true
    },
    preferences: {
      language: 'English',
      darkMode: false,
      soundEffects: true
    },
    privacy: {
      shareLocation: true,
      shareHealthData: false,
      analytics: true
    }
  });

  const languages = ['English', 'Hindi', 'Tamil', 'Telugu', 'Bengali', 'Marathi'];

  const toggleSetting = (category: string, key: string) => {
    setSettings({
      ...settings,
      [category]: {
        ...settings[category as keyof typeof settings],
        [key]: !settings[category as keyof typeof settings][key as keyof typeof settings.notifications]
      }
    });
  };

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      <div className="bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white p-6">
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center"
          >
            <X className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold">App Settings</h1>
          <div className="w-10" />
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div className="bg-white rounded-3xl shadow-md p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
              <Bell className="w-5 h-5 text-[#0A84FF]" />
            </div>
            <h3 className="font-bold text-gray-800 text-lg">Notifications</h3>
          </div>

          <div className="space-y-4">
            {[
              { key: 'bookings', label: 'Booking Updates', description: 'Get notified about booking status' },
              { key: 'messages', label: 'Messages', description: 'New messages from healthcare providers' },
              { key: 'offers', label: 'Offers & Promotions', description: 'Special deals and discounts' },
              { key: 'reminders', label: 'Appointment Reminders', description: 'Upcoming service reminders' }
            ].map((item) => (
              <div key={item.key} className="flex items-center justify-between py-3 border-b border-gray-100">
                <div className="flex-1">
                  <p className="font-semibold text-gray-800">{item.label}</p>
                  <p className="text-sm text-gray-600">{item.description}</p>
                </div>
                <button
                  onClick={() => toggleSetting('notifications', item.key)}
                  className={`w-12 h-7 rounded-full transition-all ${
                    settings.notifications[item.key as keyof typeof settings.notifications]
                      ? 'bg-[#0A84FF]'
                      : 'bg-gray-300'
                  }`}
                >
                  <div
                    className={`w-5 h-5 bg-white rounded-full shadow-md transition-all ${
                      settings.notifications[item.key as keyof typeof settings.notifications]
                        ? 'translate-x-6'
                        : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-md p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-purple-50 rounded-xl flex items-center justify-center">
              <Globe className="w-5 h-5 text-purple-500" />
            </div>
            <h3 className="font-bold text-gray-800 text-lg">Preferences</h3>
          </div>

          <div className="space-y-4">
            <div className="py-3 border-b border-gray-100">
              <label className="block mb-3">
                <span className="font-semibold text-gray-800">Language</span>
                <p className="text-sm text-gray-600 mb-3">Choose your preferred language</p>
              </label>
              <select
                value={settings.preferences.language}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    preferences: { ...settings.preferences, language: e.target.value }
                  })
                }
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0A84FF]"
              >
                {languages.map((lang) => (
                  <option key={lang} value={lang}>
                    {lang}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center justify-between py-3 border-b border-gray-100">
              <div className="flex-1">
                <p className="font-semibold text-gray-800">Dark Mode</p>
                <p className="text-sm text-gray-600">Use dark theme</p>
              </div>
              <button
                onClick={() => toggleSetting('preferences', 'darkMode')}
                className={`w-12 h-7 rounded-full transition-all ${
                  settings.preferences.darkMode ? 'bg-[#0A84FF]' : 'bg-gray-300'
                }`}
              >
                <div
                  className={`w-5 h-5 bg-white rounded-full shadow-md transition-all ${
                    settings.preferences.darkMode ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between py-3">
              <div className="flex-1">
                <p className="font-semibold text-gray-800">Sound Effects</p>
                <p className="text-sm text-gray-600">Play notification sounds</p>
              </div>
              <button
                onClick={() => toggleSetting('preferences', 'soundEffects')}
                className={`w-12 h-7 rounded-full transition-all ${
                  settings.preferences.soundEffects ? 'bg-[#0A84FF]' : 'bg-gray-300'
                }`}
              >
                <div
                  className={`w-5 h-5 bg-white rounded-full shadow-md transition-all ${
                    settings.preferences.soundEffects ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-md p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-green-50 rounded-xl flex items-center justify-center">
              <Shield className="w-5 h-5 text-green-500" />
            </div>
            <h3 className="font-bold text-gray-800 text-lg">Privacy & Security</h3>
          </div>

          <div className="space-y-4">
            {[
              {
                key: 'shareLocation',
                label: 'Share Location',
                description: 'Allow app to access your location for better service'
              },
              {
                key: 'shareHealthData',
                label: 'Share Health Data',
                description: 'Share health records with healthcare providers'
              },
              {
                key: 'analytics',
                label: 'Usage Analytics',
                description: 'Help us improve by sharing usage data'
              }
            ].map((item) => (
              <div key={item.key} className="flex items-center justify-between py-3 border-b border-gray-100">
                <div className="flex-1">
                  <p className="font-semibold text-gray-800">{item.label}</p>
                  <p className="text-sm text-gray-600">{item.description}</p>
                </div>
                <button
                  onClick={() => toggleSetting('privacy', item.key)}
                  className={`w-12 h-7 rounded-full transition-all ${
                    settings.privacy[item.key as keyof typeof settings.privacy]
                      ? 'bg-[#0A84FF]'
                      : 'bg-gray-300'
                  }`}
                >
                  <div
                    className={`w-5 h-5 bg-white rounded-full shadow-md transition-all ${
                      settings.privacy[item.key as keyof typeof settings.privacy]
                        ? 'translate-x-6'
                        : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-md p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center">
              <Database className="w-5 h-5 text-gray-600" />
            </div>
            <h3 className="font-bold text-gray-800 text-lg">Data & Storage</h3>
          </div>

          <div className="space-y-3">
            <button className="w-full flex items-center justify-between p-4 rounded-xl hover:bg-gray-50 transition-all">
              <span className="font-semibold text-gray-800">Clear Cache</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
            <button className="w-full flex items-center justify-between p-4 rounded-xl hover:bg-gray-50 transition-all">
              <span className="font-semibold text-gray-800">Download My Data</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
            <button className="w-full flex items-center justify-between p-4 rounded-xl hover:bg-gray-50 transition-all text-red-500">
              <span className="font-semibold">Delete Account</span>
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-2xl p-6 text-center">
          <p className="text-gray-700 mb-2">
            <strong>HHCS</strong> - Home Health Care Service
          </p>
          <p className="text-sm text-gray-600 mb-1">Version 1.0.0</p>
          <p className="text-xs text-gray-500 italic">SEVA PARMO DHARMAH</p>
        </div>
      </div>
    </div>
  );
}
