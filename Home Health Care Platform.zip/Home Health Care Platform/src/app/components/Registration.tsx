import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  User, Mail, Phone, Lock, MapPin, Upload, Camera, CreditCard,
  Eye, EyeOff, CheckCircle, AlertCircle, FileText, Shield
} from 'lucide-react';

export default function Registration() {
  const { role } = useParams<{ role: string }>();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    mobile: '',
    email: '',
    otp: '',
    address: '',
    password: '',
    confirmPassword: '',
    emergencyContact: '',
    certificate: null,
    aadhaar: null,
    selfie: null,
    bankUpi: ''
  });

  const getRoleDetails = () => {
    switch (role) {
      case 'client':
        return {
          title: 'CLIENT Registration',
          color: 'from-[#0A84FF] to-[#0066CC]',
          icon: '👤',
          steps: 4
        };
      case 'caretaker':
        return {
          title: 'CARETAKER Registration',
          color: 'from-[#34C759] to-[#28A745]',
          icon: '👨‍⚕️',
          steps: 5
        };
      case 'nurse':
        return {
          title: 'NURSE Registration',
          color: 'from-[#0A84FF] to-[#0066CC]',
          icon: '👩‍⚕️',
          steps: 5
        };
      case 'doctor':
        return {
          title: 'DOCTOR Registration',
          color: 'from-[#AF52DE] to-[#9933CC]',
          icon: '👨‍⚕️',
          steps: 5
        };
      default:
        return {
          title: 'Registration',
          color: 'from-[#0A84FF] to-[#0066CC]',
          icon: '👤',
          steps: 4
        };
    }
  };

  const roleDetails = getRoleDetails();

  const handleNext = () => {
    if (step < roleDetails.steps) {
      setStep(step + 1);
    } else {
      handleSubmit();
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleSubmit = () => {
    navigate(`/${role}-dashboard`);
  };

  const handleFileUpload = (field: string) => {
    alert(`${field} upload functionality - In production, this would open file picker`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 p-6">
      <div className="max-w-2xl mx-auto py-8">
        <div className="text-center mb-8">
          <div className={`w-20 h-20 bg-gradient-to-br ${roleDetails.color} rounded-3xl mx-auto mb-4 flex items-center justify-center shadow-xl text-3xl`}>
            {roleDetails.icon}
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{roleDetails.title}</h1>
          <p className="text-gray-600">Step {step} of {roleDetails.steps}</p>
        </div>

        <div className="flex gap-2 mb-8">
          {[...Array(roleDetails.steps)].map((_, index) => (
            <div
              key={index}
              className={`flex-1 h-2 rounded-full transition-all ${
                index < step ? `bg-gradient-to-r ${roleDetails.color}` : 'bg-gray-200'
              }`}
            />
          ))}
        </div>

        <div className="bg-white rounded-3xl shadow-xl p-8">
          {step === 1 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Personal Information</h2>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Full Name *
                </label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    placeholder="Enter your full name"
                    className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0A84FF]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Mobile Number *
                </label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="tel"
                    value={formData.mobile}
                    onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                    placeholder="+91 XXXXX XXXXX"
                    className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0A84FF]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Email Address *
                </label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="your.email@example.com"
                    className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0A84FF]"
                  />
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Verification</h2>

              <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-6 mb-6">
                <div className="flex items-center gap-3 mb-3">
                  <Shield className="w-6 h-6 text-[#0A84FF]" />
                  <h3 className="font-semibold text-gray-800">OTP Verification</h3>
                </div>
                <p className="text-sm text-gray-600 mb-4">
                  We've sent a verification code to {formData.mobile || 'your mobile'}
                </p>
                <input
                  type="text"
                  value={formData.otp}
                  onChange={(e) => setFormData({ ...formData, otp: e.target.value })}
                  placeholder="Enter 6-digit OTP"
                  maxLength={6}
                  className="w-full px-4 py-4 bg-white border border-gray-200 rounded-xl text-center text-2xl tracking-widest focus:outline-none focus:ring-2 focus:ring-[#0A84FF]"
                />
                <button className="w-full mt-4 text-[#0A84FF] font-semibold text-sm">
                  Resend OTP
                </button>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Complete Address *
                </label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-4 w-5 h-5 text-gray-400" />
                  <textarea
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    placeholder="House/Flat No., Street, Area, City, State, Pincode"
                    rows={4}
                    className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0A84FF]"
                  />
                </div>
              </div>

              {role === 'client' && (
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Emergency Contact Number
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="tel"
                      value={formData.emergencyContact}
                      onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
                      placeholder="+91 XXXXX XXXXX"
                      className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0A84FF]"
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Security</h2>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Create Password *
                </label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    placeholder="Enter strong password"
                    className="w-full pl-12 pr-12 py-4 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0A84FF]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2"
                  >
                    {showPassword ? (
                      <EyeOff className="w-5 h-5 text-gray-400" />
                    ) : (
                      <Eye className="w-5 h-5 text-gray-400" />
                    )}
                  </button>
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  Must be at least 8 characters with uppercase, lowercase, and numbers
                </p>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Confirm Password *
                </label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                    placeholder="Re-enter password"
                    className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0A84FF]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Profile Photo
                </label>
                <button
                  onClick={() => handleFileUpload('Profile Photo')}
                  className="w-full border-2 border-dashed border-gray-300 rounded-2xl p-8 hover:border-[#0A84FF] transition-all"
                >
                  <Camera className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-600 font-semibold">Upload Profile Photo</p>
                  <p className="text-sm text-gray-500 mt-1">JPG, PNG (Max 5MB)</p>
                </button>
              </div>
            </div>
          )}

          {step === 4 && role !== 'client' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Document Verification</h2>

              <div className="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-6 mb-6">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-800 mb-1">Important</h3>
                    <p className="text-sm text-gray-600">
                      All documents will be verified by our team. Please upload clear, valid documents.
                    </p>
                  </div>
                </div>
              </div>

              {role === 'caretaker' && (
                <>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      10th Certificate *
                    </label>
                    <button
                      onClick={() => handleFileUpload('10th Certificate')}
                      className="w-full border-2 border-dashed border-gray-300 rounded-2xl p-6 hover:border-[#0A84FF] transition-all"
                    >
                      <FileText className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600 font-semibold">Upload 10th Certificate</p>
                      <p className="text-sm text-gray-500 mt-1">PDF, JPG, PNG (Max 5MB)</p>
                    </button>
                  </div>
                </>
              )}

              {role === 'nurse' && (
                <>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Nursing Certificate (ANM/GNM/BSc/MSc) *
                    </label>
                    <button
                      onClick={() => handleFileUpload('Nursing Certificate')}
                      className="w-full border-2 border-dashed border-gray-300 rounded-2xl p-6 hover:border-[#0A84FF] transition-all"
                    >
                      <FileText className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600 font-semibold">Upload Nursing Certificate</p>
                      <p className="text-sm text-gray-500 mt-1">PDF, JPG, PNG (Max 5MB)</p>
                    </button>
                  </div>
                </>
              )}

              {role === 'doctor' && (
                <>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      MBBS Certificate *
                    </label>
                    <button
                      onClick={() => handleFileUpload('MBBS Certificate')}
                      className="w-full border-2 border-dashed border-gray-300 rounded-2xl p-6 hover:border-[#0A84FF] transition-all"
                    >
                      <FileText className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600 font-semibold">Upload MBBS Certificate</p>
                      <p className="text-sm text-gray-500 mt-1">PDF, JPG, PNG (Max 5MB)</p>
                    </button>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Specialization Certificate
                    </label>
                    <button
                      onClick={() => handleFileUpload('Specialization Certificate')}
                      className="w-full border-2 border-dashed border-gray-300 rounded-2xl p-6 hover:border-[#0A84FF] transition-all"
                    >
                      <FileText className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600 font-semibold">Upload Specialization</p>
                      <p className="text-sm text-gray-500 mt-1">MD, MS, etc. (Optional)</p>
                    </button>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Medical License *
                    </label>
                    <button
                      onClick={() => handleFileUpload('Medical License')}
                      className="w-full border-2 border-dashed border-gray-300 rounded-2xl p-6 hover:border-[#0A84FF] transition-all"
                    >
                      <FileText className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600 font-semibold">Upload Medical License</p>
                      <p className="text-sm text-gray-500 mt-1">Valid license required</p>
                    </button>
                  </div>
                </>
              )}

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Aadhaar Card *
                </label>
                <button
                  onClick={() => handleFileUpload('Aadhaar Card')}
                  className="w-full border-2 border-dashed border-gray-300 rounded-2xl p-6 hover:border-[#0A84FF] transition-all"
                >
                  <Upload className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-600 font-semibold">Upload Aadhaar Card</p>
                  <p className="text-sm text-gray-500 mt-1">Front and Back</p>
                </button>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Selfie Verification *
                </label>
                <button
                  onClick={() => handleFileUpload('Selfie')}
                  className="w-full border-2 border-dashed border-gray-300 rounded-2xl p-6 hover:border-[#0A84FF] transition-all"
                >
                  <Camera className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-600 font-semibold">Take Selfie</p>
                  <p className="text-sm text-gray-500 mt-1">Clear face photo required</p>
                </button>
              </div>
            </div>
          )}

          {((step === 4 && role === 'client') || (step === 5 && role !== 'client')) && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Payment Setup</h2>

              <div className="bg-green-50 border-2 border-green-200 rounded-2xl p-6 mb-6">
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-800 mb-1">Secure Payment</h3>
                    <p className="text-sm text-gray-600">
                      {role === 'client'
                        ? 'Add payment method for booking services. All transactions are encrypted and secure.'
                        : 'Add bank/UPI details to receive your earnings directly.'}
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {role === 'client' ? 'UPI ID (Recommended)' : 'Bank Account / UPI ID *'}
                </label>
                <div className="relative">
                  <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={formData.bankUpi}
                    onChange={(e) => setFormData({ ...formData, bankUpi: e.target.value })}
                    placeholder={role === 'client' ? 'yourname@upi' : 'Enter UPI ID or Account Number'}
                    className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0A84FF]"
                  />
                </div>
              </div>

              {role === 'client' && (
                <>
                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-gray-300"></div>
                    </div>
                    <div className="relative flex justify-center text-sm">
                      <span className="px-4 bg-white text-gray-500">OR</span>
                    </div>
                  </div>

                  <button className="w-full border-2 border-gray-300 rounded-2xl p-6 hover:border-[#0A84FF] transition-all">
                    <CreditCard className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-600 font-semibold">Add Debit/Credit Card</p>
                    <p className="text-sm text-gray-500 mt-1">Visa, Mastercard, RuPay</p>
                  </button>
                </>
              )}

              <div className="bg-blue-50 rounded-2xl p-6">
                <h3 className="font-semibold text-gray-800 mb-3">Terms & Conditions</h3>
                <div className="space-y-2 text-sm text-gray-600">
                  <label className="flex items-start gap-3">
                    <input type="checkbox" className="mt-1 w-5 h-5 text-[#0A84FF] rounded" />
                    <span>I agree to HHCS Terms of Service and Privacy Policy</span>
                  </label>
                  <label className="flex items-start gap-3">
                    <input type="checkbox" className="mt-1 w-5 h-5 text-[#0A84FF] rounded" />
                    <span>I consent to background verification and document checks</span>
                  </label>
                  {role !== 'client' && (
                    <label className="flex items-start gap-3">
                      <input type="checkbox" className="mt-1 w-5 h-5 text-[#0A84FF] rounded" />
                      <span>I understand that 23% service fee applies to all earnings</span>
                    </label>
                  )}
                </div>
              </div>
            </div>
          )}

          <div className="flex gap-4 mt-8">
            {step > 1 && (
              <button
                onClick={handleBack}
                className="flex-1 bg-gray-100 text-gray-700 py-4 rounded-xl font-semibold hover:bg-gray-200 transition-all"
              >
                Back
              </button>
            )}
            <button
              onClick={handleNext}
              className={`flex-1 bg-gradient-to-r ${roleDetails.color} text-white py-4 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all`}
            >
              {step === roleDetails.steps ? 'Complete Registration' : 'Continue'}
            </button>
          </div>
        </div>

        <div className="text-center mt-6">
          <p className="text-gray-600">
            Already have an account?{' '}
            <button
              onClick={() => navigate('/login')}
              className="text-[#0A84FF] font-semibold hover:underline"
            >
              Login
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
