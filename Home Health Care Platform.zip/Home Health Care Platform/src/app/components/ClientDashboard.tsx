import { useState } from 'react';
import {
  Home, Calendar, MessageCircle, Bell, User, Search, AlertCircle,
  Heart, Stethoscope, Syringe, Dumbbell, Bed, Users, Activity,
  Plus, MapPin, Clock, Star, Phone, Video, ChevronRight, Wallet,
  FileText, Gift, TrendingUp
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function ClientDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('home');

  const services = [
    { name: 'Caretaker', icon: Heart, color: 'from-[#34C759] to-[#28A745]', path: '/booking/caretaker' },
    { name: 'Nurse', icon: Stethoscope, color: 'from-[#0A84FF] to-[#0066CC]', path: '/booking/nurse' },
    { name: 'Doctor', icon: Activity, color: 'from-[#AF52DE] to-[#9933CC]', path: '/booking/doctor' },
    { name: 'Physiotherapy', icon: Dumbbell, color: 'from-[#FF9500] to-[#FF6B00]', path: '/booking/physiotherapy' },
    { name: 'ICU Setup', icon: Bed, color: 'from-[#FF3B30] to-[#CC2E26]', path: '/booking/icu' },
    { name: 'Elder Care', icon: Users, color: 'from-[#5AC8FA] to-[#0098DB]', path: '/booking/elder-care' },
    { name: 'Rehabilitation', icon: Plus, color: 'from-[#FF2D55] to-[#CC2444]', path: '/booking/rehabilitation' },
    { name: 'Home Injection', icon: Syringe, color: 'from-[#34C759] to-[#28A745]', path: '/booking/injection' },
  ];

  const upcomingBookings = [
    {
      id: 1,
      service: 'Nurse',
      name: 'Sarah Johnson',
      time: 'Today, 3:00 PM',
      status: 'confirmed',
      avatar: '👩‍⚕️'
    },
    {
      id: 2,
      service: 'Caretaker',
      name: 'Michael Brown',
      time: 'Tomorrow, 9:00 AM',
      status: 'pending',
      avatar: '👨‍⚕️'
    }
  ];

  return (
    <div className="min-h-screen bg-[#F5F7FA] pb-20">
      {activeTab === 'home' && (
        <div className="p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-800">Welcome Back!</h1>
              <p className="text-gray-600">How can we help you today?</p>
            </div>
            <button
              onClick={() => navigate('/emergency-sos')}
              className="w-12 h-12 bg-gradient-to-br from-[#FF3B30] to-[#CC2E26] rounded-2xl flex items-center justify-center shadow-lg"
            >
              <AlertCircle className="w-6 h-6 text-white" />
            </button>
          </div>

          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search healthcare services..."
              className="w-full pl-12 pr-4 py-4 bg-white border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#0A84FF] shadow-sm"
            />
          </div>

          <div className="bg-gradient-to-r from-[#0A84FF] to-[#0066CC] rounded-3xl p-6 text-white shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 mb-1">Emergency Support</p>
                <h3 className="text-2xl font-bold">24/7 Available</h3>
                <p className="text-blue-100 mt-2 text-sm">Tap SOS for immediate help</p>
              </div>
              <button className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                <span className="text-2xl font-bold">SOS</span>
              </button>
            </div>
          </div>

          <div>
            <h2 className="text-xl font-bold text-gray-800 mb-4">Our Services</h2>
            <div className="grid grid-cols-2 gap-4">
              {services.map((service, index) => (
                <button
                  key={index}
                  onClick={() => navigate(service.path)}
                  className="bg-white rounded-2xl p-5 shadow-md hover:shadow-xl transition-all"
                >
                  <div className={`w-12 h-12 bg-gradient-to-br ${service.color} rounded-xl flex items-center justify-center mb-3`}>
                    <service.icon className="w-6 h-6 text-white" />
                  </div>
                  <p className="text-sm font-semibold text-gray-800">{service.name}</p>
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-gray-800">Upcoming Bookings</h2>
              <button className="text-[#0A84FF] font-semibold text-sm">View All</button>
            </div>
            <div className="space-y-3">
              {upcomingBookings.map((booking) => (
                <div key={booking.id} className="bg-white rounded-2xl p-4 shadow-md">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-gradient-to-br from-[#0A84FF] to-[#0066CC] rounded-xl flex items-center justify-center text-2xl">
                      {booking.avatar}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-800">{booking.name}</h3>
                      <p className="text-sm text-gray-600">{booking.service}</p>
                      <div className="flex items-center gap-1 mt-1">
                        <Clock className="w-3 h-3 text-gray-400" />
                        <span className="text-xs text-gray-500">{booking.time}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => alert(`Calling ${booking.name}...`)}
                        className="w-10 h-10 bg-[#34C759] rounded-xl flex items-center justify-center"
                      >
                        <Phone className="w-5 h-5 text-white" />
                      </button>
                      <button
                        onClick={() => navigate('/chat')}
                        className="w-10 h-10 bg-[#0A84FF] rounded-xl flex items-center justify-center"
                      >
                        <MessageCircle className="w-5 h-5 text-white" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-3xl p-6 shadow-md">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-gray-800">Nearby Healthcare Staff</h2>
              <MapPin className="w-5 h-5 text-[#0A84FF]" />
            </div>
            <div className="h-48 bg-gradient-to-br from-blue-100 to-green-100 rounded-2xl flex items-center justify-center">
              <div className="text-center">
                <MapPin className="w-12 h-12 text-[#0A84FF] mx-auto mb-2" />
                <p className="text-gray-600">Live Map View</p>
                <p className="text-sm text-gray-500">12 professionals nearby</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {[
              { label: 'Wallet', icon: Wallet, path: '/wallet', color: 'from-green-500 to-green-600' },
              { label: 'History', icon: FileText, path: '/service-history', color: 'from-blue-500 to-blue-600' },
              { label: 'Rewards', icon: Gift, path: '/rewards', color: 'from-yellow-500 to-orange-500' },
              { label: 'Health', icon: Activity, path: '/health-records', color: 'from-purple-500 to-purple-600' }
            ].map((item, index) => (
              <button
                key={index}
                onClick={() => navigate(item.path)}
                className={`bg-gradient-to-br ${item.color} text-white p-5 rounded-2xl shadow-md flex flex-col items-center gap-2`}
              >
                <item.icon className="w-8 h-8" />
                <span className="font-semibold">{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'bookings' && (
        <div className="p-6">
          <h1 className="text-2xl font-bold text-gray-800 mb-6">My Bookings</h1>
          <div className="space-y-4">
            {[...upcomingBookings, ...upcomingBookings].map((booking, index) => (
              <div key={index} className="bg-white rounded-2xl p-5 shadow-md">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-[#0A84FF] to-[#0066CC] rounded-xl flex items-center justify-center text-xl">
                      {booking.avatar}
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-800">{booking.name}</h3>
                      <p className="text-sm text-gray-600">{booking.service}</p>
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    booking.status === 'confirmed'
                      ? 'bg-green-100 text-green-700'
                      : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {booking.status}
                  </span>
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>{booking.time}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                    <span>4.8</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => navigate('/live-tracking')}
                    className="flex-1 bg-[#0A84FF] text-white py-3 rounded-xl font-semibold"
                  >
                    Track Live
                  </button>
                  <button
                    onClick={() => navigate('/chat')}
                    className="px-4 bg-gray-100 rounded-xl"
                  >
                    <MessageCircle className="w-5 h-5 text-gray-600" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'profile' && (
        <div className="p-6">
          <div className="bg-white rounded-3xl p-6 shadow-md mb-6">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-20 h-20 bg-gradient-to-br from-[#0A84FF] to-[#0066CC] rounded-2xl flex items-center justify-center text-3xl">
                👤
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-800">John Doe</h2>
                <p className="text-gray-600">john.doe@email.com</p>
                <p className="text-sm text-gray-500">+91 9876543210</p>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            {[
              { label: 'Profile & Settings', icon: User, path: '/profile-settings' },
              { label: 'Wallet & Payments', icon: Wallet, path: '/wallet' },
              { label: 'Service History', icon: FileText, path: '/service-history' },
              { label: 'Health Records', icon: Activity, path: '/health-records' },
              { label: 'Rewards & Loyalty', icon: Gift, path: '/rewards' },
              { label: 'Help & Support', icon: AlertCircle, path: '/profile-settings' },
            ].map((item, index) => (
              <button
                key={index}
                onClick={() => navigate(item.path)}
                className="w-full bg-white rounded-2xl p-4 shadow-md flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <item.icon className="w-5 h-5 text-[#0A84FF]" />
                  <span className="font-semibold text-gray-800">{item.label}</span>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>
            ))}
            <button
              onClick={() => {
                if (confirm('Are you sure you want to logout?')) {
                  navigate('/login');
                }
              }}
              className="w-full bg-[#FF3B30] text-white rounded-2xl p-4 font-semibold shadow-md"
            >
              Logout
            </button>
          </div>
        </div>
      )}

      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-4">
        <div className="flex items-center justify-around max-w-md mx-auto">
          {[
            { id: 'home', icon: Home, label: 'Home', path: null },
            { id: 'bookings', icon: Calendar, label: 'Bookings', path: null },
            { id: 'chat', icon: MessageCircle, label: 'Chat', path: '/chat' },
            { id: 'notifications', icon: Bell, label: 'Alerts', path: '/notifications' },
            { id: 'profile', icon: User, label: 'Profile', path: null }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                if (tab.path) {
                  navigate(tab.path);
                } else {
                  setActiveTab(tab.id);
                }
              }}
              className={`flex flex-col items-center gap-1 ${
                activeTab === tab.id ? 'text-[#0A84FF]' : 'text-gray-400'
              }`}
            >
              <tab.icon className="w-6 h-6" />
              <span className="text-xs">{tab.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
