import { useState } from 'react';
import { Home, DollarSign, User, Bell, Video, FileText, Calendar, Activity, Phone } from 'lucide-react';

export default function DoctorDashboard() {
  const [activeTab, setActiveTab] = useState('home');

  const appointments = [
    {
      id: 1,
      patient: 'John Doe',
      time: '10:00 AM',
      type: 'Video Consultation',
      issue: 'Follow-up checkup',
      fee: '₹1,500',
      status: 'upcoming'
    },
    {
      id: 2,
      patient: 'Sarah Smith',
      time: '11:30 AM',
      type: 'Phone Consultation',
      issue: 'Cold and fever',
      fee: '₹1,000',
      status: 'upcoming'
    }
  ];

  return (
    <div className="min-h-screen bg-[#F5F7FA] pb-20">
      {activeTab === 'home' && (
        <div className="p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-800">Dr. Dashboard</h1>
              <p className="text-gray-600">Consultation Schedule</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-[#AF52DE] to-[#9933CC] rounded-2xl flex items-center justify-center shadow-lg text-2xl">
              👨‍⚕️
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-[#AF52DE] to-[#9933CC] rounded-2xl p-5 text-white shadow-lg">
              <Calendar className="w-8 h-8 mb-2" />
              <p className="text-sm opacity-90">Today's Appointments</p>
              <p className="text-2xl font-bold">{appointments.length}</p>
            </div>
            <div className="bg-gradient-to-br from-[#34C759] to-[#28A745] rounded-2xl p-5 text-white shadow-lg">
              <DollarSign className="w-8 h-8 mb-2" />
              <p className="text-sm opacity-90">Today's Earnings</p>
              <p className="text-2xl font-bold">₹12,500</p>
            </div>
          </div>

          <div>
            <h2 className="text-xl font-bold text-gray-800 mb-4">Upcoming Consultations</h2>
            <div className="space-y-4">
              {appointments.map((appointment) => (
                <div key={appointment.id} className="bg-white rounded-2xl p-5 shadow-md">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-bold text-gray-800 text-lg">{appointment.patient}</h3>
                      <p className="text-sm text-gray-600">{appointment.issue}</p>
                    </div>
                    <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-xs font-semibold">
                      {appointment.time}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 mb-3">
                    {appointment.type === 'Video Consultation' ? (
                      <Video className="w-4 h-4 text-[#0A84FF]" />
                    ) : (
                      <Phone className="w-4 h-4 text-[#34C759]" />
                    )}
                    <span className="text-sm text-gray-600">{appointment.type}</span>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                    <span className="text-[#34C759] font-bold">{appointment.fee}</span>
                    <button className="bg-gradient-to-r from-[#AF52DE] to-[#9933CC] text-white px-6 py-2 rounded-lg font-semibold flex items-center gap-2">
                      <Video className="w-4 h-4" />
                      Start Call
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl p-5 shadow-md">
            <h3 className="font-bold text-gray-800 mb-4">Quick Actions</h3>
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: 'Write Prescription', icon: FileText, color: 'from-[#0A84FF] to-[#0066CC]' },
                { label: 'Upload Report', icon: Activity, color: 'from-[#34C759] to-[#28A745]' },
                { label: 'View Patients', icon: User, color: 'from-[#AF52DE] to-[#9933CC]' },
                { label: 'Emergency', icon: Bell, color: 'from-[#FF3B30] to-[#CC2E26]' },
              ].map((action, index) => (
                <button
                  key={index}
                  className={`bg-gradient-to-br ${action.color} text-white p-4 rounded-xl flex flex-col items-center gap-2 shadow-md`}
                >
                  <action.icon className="w-6 h-6" />
                  <span className="text-sm font-semibold">{action.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'earnings' && (
        <div className="p-6 space-y-6">
          <h1 className="text-2xl font-bold text-gray-800">Earnings</h1>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white rounded-2xl p-5 shadow-md">
              <p className="text-sm text-gray-600 mb-1">This Week</p>
              <p className="text-2xl font-bold text-gray-800">₹67,500</p>
            </div>
            <div className="bg-white rounded-2xl p-5 shadow-md">
              <p className="text-sm text-gray-600 mb-1">This Month</p>
              <p className="text-2xl font-bold text-gray-800">₹2,45,000</p>
            </div>
          </div>

          <div className="bg-gradient-to-br from-[#34C759] to-[#28A745] rounded-2xl p-6 text-white shadow-lg">
            <p className="text-sm opacity-90 mb-2">Available Balance</p>
            <p className="text-3xl font-bold mb-4">₹1,89,000</p>
            <button className="w-full bg-white text-[#34C759] py-3 rounded-xl font-semibold">
              Withdraw Earnings
            </button>
          </div>
        </div>
      )}

      {activeTab === 'profile' && (
        <div className="p-6 space-y-6">
          <div className="bg-white rounded-2xl p-6 shadow-md">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-20 h-20 bg-gradient-to-br from-[#AF52DE] to-[#9933CC] rounded-2xl flex items-center justify-center text-3xl">
                👨‍⚕️
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-800">Dr. Amit Kumar</h2>
                <p className="text-gray-600">MBBS, MD - Internal Medicine</p>
                <p className="text-sm text-gray-500 mt-1">15 years experience</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-md">
            <h3 className="font-bold text-gray-800 mb-4">Licenses & Certifications</h3>
            <div className="space-y-3">
              {[
                { name: 'MBBS Certificate', status: 'verified' },
                { name: 'MD Specialization', status: 'verified' },
                { name: 'Medical License', status: 'verified' },
                { name: 'Aadhaar Card', status: 'verified' },
              ].map((doc, index) => (
                <div key={index} className="flex items-center justify-between py-3 border-b border-gray-100">
                  <span className="text-gray-800">{doc.name}</span>
                  <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-semibold">
                    {doc.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-4">
        <div className="flex items-center justify-around max-w-md mx-auto">
          {[
            { id: 'home', icon: Home, label: 'Home' },
            { id: 'earnings', icon: DollarSign, label: 'Earnings' },
            { id: 'notifications', icon: Bell, label: 'Alerts' },
            { id: 'profile', icon: User, label: 'Profile' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center gap-1 ${
                activeTab === tab.id ? 'text-[#AF52DE]' : 'text-gray-400'
              }`}
            >
              <tab.icon className="w-6 h-6" />
              <span className="text-xs">{tab.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
