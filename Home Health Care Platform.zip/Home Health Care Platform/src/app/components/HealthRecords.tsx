import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FileText, Upload, Download, Share2, Plus, X, Calendar,
  Activity, Heart, Droplet, TrendingUp, Eye, ChevronRight
} from 'lucide-react';

export default function HealthRecords() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'records' | 'vitals' | 'prescriptions'>('records');

  const medicalRecords = [
    {
      id: 1,
      title: 'Blood Test Report',
      date: 'May 15, 2026',
      doctor: 'Dr. Amit Kumar',
      type: 'Lab Report',
      fileSize: '2.4 MB',
      status: 'normal',
      icon: Droplet,
      color: 'from-red-500 to-pink-500'
    },
    {
      id: 2,
      title: 'Prescription',
      date: 'May 12, 2026',
      doctor: 'Dr. Priya Sharma',
      type: 'Prescription',
      fileSize: '1.2 MB',
      status: 'active',
      icon: FileText,
      color: 'from-[#0A84FF] to-[#0066CC]'
    },
    {
      id: 3,
      title: 'X-Ray Chest',
      date: 'May 8, 2026',
      doctor: 'Dr. Rajesh Gupta',
      type: 'Imaging',
      fileSize: '5.8 MB',
      status: 'normal',
      icon: Activity,
      color: 'from-purple-500 to-indigo-500'
    }
  ];

  const vitalSigns = [
    {
      id: 1,
      name: 'Blood Pressure',
      value: '120/80',
      unit: 'mmHg',
      status: 'normal',
      icon: Heart,
      color: 'text-green-500',
      bgColor: 'bg-green-50',
      lastUpdated: '2 hours ago'
    },
    {
      id: 2,
      name: 'Heart Rate',
      value: '72',
      unit: 'bpm',
      status: 'normal',
      icon: Activity,
      color: 'text-blue-500',
      bgColor: 'bg-blue-50',
      lastUpdated: '2 hours ago'
    },
    {
      id: 3,
      name: 'Blood Sugar',
      value: '95',
      unit: 'mg/dL',
      status: 'normal',
      icon: Droplet,
      color: 'text-red-500',
      bgColor: 'bg-red-50',
      lastUpdated: '5 hours ago'
    },
    {
      id: 4,
      name: 'Oxygen Level',
      value: '98',
      unit: '%',
      status: 'normal',
      icon: TrendingUp,
      color: 'text-purple-500',
      bgColor: 'bg-purple-50',
      lastUpdated: '2 hours ago'
    }
  ];

  const prescriptions = [
    {
      id: 1,
      medication: 'Amoxicillin 500mg',
      dosage: '1 tablet, 3 times daily',
      duration: '7 days',
      prescribedBy: 'Dr. Amit Kumar',
      date: 'May 12, 2026',
      status: 'active',
      remaining: '5 days'
    },
    {
      id: 2,
      medication: 'Vitamin D3 60000 IU',
      dosage: '1 capsule, weekly',
      duration: '8 weeks',
      prescribedBy: 'Dr. Priya Sharma',
      date: 'May 1, 2026',
      status: 'active',
      remaining: '6 weeks'
    }
  ];

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      <div className="bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white p-6">
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center"
          >
            <X className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold">Health Records</h1>
          <button
            onClick={() => alert('Upload new record')}
            className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center"
          >
            <Upload className="w-6 h-6" />
          </button>
        </div>

        <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-5">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center">
              <FileText className="w-8 h-8" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-blue-100 mb-1">Total Records</p>
              <p className="text-3xl font-bold">{medicalRecords.length + prescriptions.length}</p>
            </div>
            <button
              onClick={() => alert('Share all records')}
              className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center"
            >
              <Share2 className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {[
            { id: 'records', label: 'Records', icon: FileText },
            { id: 'vitals', label: 'Vitals', icon: Activity },
            { id: 'prescriptions', label: 'Prescriptions', icon: Heart }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-5 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-[#0A84FF] text-white'
                  : 'bg-white text-gray-700'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              {tab.label}
            </button>
          ))}
        </div>

        {activeTab === 'records' && (
          <div className="space-y-4">
            <div className="bg-gradient-to-br from-blue-50 to-green-50 border-2 border-blue-200 rounded-2xl p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-[#0A84FF] to-[#34C759] rounded-xl flex items-center justify-center">
                  <Upload className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-gray-800 mb-2">Upload Medical Records</h3>
                  <p className="text-sm text-gray-600 mb-4">
                    Keep all your medical documents in one secure place
                  </p>
                  <button
                    onClick={() => alert('Upload document')}
                    className="bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white px-6 py-3 rounded-xl font-semibold flex items-center gap-2"
                  >
                    <Plus className="w-5 h-5" />
                    Upload Document
                  </button>
                </div>
              </div>
            </div>

            {medicalRecords.map((record) => {
              const Icon = record.icon;
              return (
                <div key={record.id} className="bg-white rounded-2xl p-5 shadow-md">
                  <div className="flex items-start gap-4">
                    <div className={`w-14 h-14 bg-gradient-to-br ${record.color} rounded-xl flex items-center justify-center flex-shrink-0`}>
                      <Icon className="w-7 h-7 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-gray-800 mb-1">{record.title}</h3>
                      <p className="text-sm text-gray-600 mb-2">{record.doctor}</p>
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          <span>{record.date}</span>
                        </div>
                        <span>•</span>
                        <span>{record.type}</span>
                        <span>•</span>
                        <span>{record.fileSize}</span>
                      </div>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold flex-shrink-0 ${
                      record.status === 'normal'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-yellow-100 text-yellow-700'
                    }`}>
                      {record.status}
                    </span>
                  </div>

                  <div className="flex gap-2 mt-4 pt-4 border-t border-gray-100">
                    <button className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-semibold flex items-center justify-center gap-2">
                      <Eye className="w-5 h-5" />
                      View
                    </button>
                    <button className="flex-1 bg-[#0A84FF] text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2">
                      <Download className="w-5 h-5" />
                      Download
                    </button>
                    <button className="px-4 bg-gray-100 rounded-xl">
                      <Share2 className="w-5 h-5 text-gray-600" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {activeTab === 'vitals' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl p-6 shadow-md">
              <h3 className="font-bold text-gray-800 mb-4">Latest Readings</h3>
              <div className="grid grid-cols-2 gap-4">
                {vitalSigns.map((vital) => {
                  const Icon = vital.icon;
                  return (
                    <div key={vital.id} className={`${vital.bgColor} rounded-xl p-4`}>
                      <Icon className={`w-6 h-6 ${vital.color} mb-2`} />
                      <p className="text-sm text-gray-600 mb-1">{vital.name}</p>
                      <p className="text-2xl font-bold text-gray-800">
                        {vital.value} <span className="text-sm text-gray-600">{vital.unit}</span>
                      </p>
                      <p className="text-xs text-gray-500 mt-1">{vital.lastUpdated}</p>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-gray-800">Vital Trends</h3>
                <button className="text-[#0A84FF] font-semibold text-sm">View All</button>
              </div>
              <div className="h-48 bg-gradient-to-br from-blue-50 to-green-50 rounded-xl flex items-center justify-center">
                <div className="text-center">
                  <TrendingUp className="w-12 h-12 text-[#0A84FF] mx-auto mb-3" />
                  <p className="text-gray-600 font-semibold">Health Trend Chart</p>
                  <p className="text-sm text-gray-500">Track your vitals over time</p>
                </div>
              </div>
            </div>

            <button
              onClick={() => alert('Record new vitals')}
              className="w-full bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white py-4 rounded-2xl font-semibold flex items-center justify-center gap-2"
            >
              <Plus className="w-5 h-5" />
              Record New Vitals
            </button>
          </div>
        )}

        {activeTab === 'prescriptions' && (
          <div className="space-y-4">
            {prescriptions.map((prescription) => (
              <div key={prescription.id} className="bg-white rounded-2xl p-5 shadow-md">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="font-bold text-gray-800 text-lg mb-2">{prescription.medication}</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2 text-gray-600">
                        <div className="w-2 h-2 bg-[#0A84FF] rounded-full"></div>
                        <span><strong>Dosage:</strong> {prescription.dosage}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <div className="w-2 h-2 bg-[#34C759] rounded-full"></div>
                        <span><strong>Duration:</strong> {prescription.duration}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <div className="w-2 h-2 bg-[#FF9500] rounded-full"></div>
                        <span><strong>Prescribed by:</strong> {prescription.prescribedBy}</span>
                      </div>
                    </div>
                  </div>
                  <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-semibold">
                    {prescription.status}
                  </span>
                </div>

                <div className="bg-blue-50 rounded-xl p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Time Remaining</p>
                      <p className="text-xl font-bold text-[#0A84FF]">{prescription.remaining}</p>
                    </div>
                    <button className="bg-[#0A84FF] text-white px-6 py-3 rounded-xl font-semibold flex items-center gap-2">
                      <Calendar className="w-5 h-5" />
                      Set Reminder
                    </button>
                  </div>
                </div>
              </div>
            ))}

            <div className="bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200 rounded-2xl p-6">
              <h3 className="font-bold text-gray-800 mb-2">Need a Prescription?</h3>
              <p className="text-sm text-gray-600 mb-4">
                Book an online consultation with our verified doctors
              </p>
              <button
                onClick={() => navigate('/booking/doctor')}
                className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-xl font-semibold flex items-center gap-2"
              >
                Book Doctor Consultation
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
