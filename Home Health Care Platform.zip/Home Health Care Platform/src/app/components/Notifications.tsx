import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Bell, CheckCircle, AlertCircle, Calendar, DollarSign,
  X, Star, MessageCircle, Clock, ChevronRight
} from 'lucide-react';

export default function Notifications() {
  const navigate = useNavigate();
  const [filter, setFilter] = useState<'all' | 'bookings' | 'payments' | 'messages'>('all');

  const notifications = [
    {
      id: 1,
      type: 'booking',
      icon: CheckCircle,
      color: 'bg-green-500',
      title: 'Booking Confirmed',
      message: 'Your booking with Sarah Johnson is confirmed for May 20, 10:00 AM',
      time: '5 mins ago',
      read: false,
      action: () => navigate('/live-tracking')
    },
    {
      id: 2,
      type: 'payment',
      icon: DollarSign,
      color: 'bg-blue-500',
      title: 'Payment Successful',
      message: '₹3,450 paid successfully via UPI. Transaction ID: TXN123456789',
      time: '10 mins ago',
      read: false
    },
    {
      id: 3,
      type: 'message',
      icon: MessageCircle,
      color: 'bg-purple-500',
      title: 'New Message',
      message: 'Sarah Johnson: I\'m on my way to your location',
      time: '15 mins ago',
      read: false,
      action: () => navigate('/chat')
    },
    {
      id: 4,
      type: 'booking',
      icon: Clock,
      color: 'bg-yellow-500',
      title: 'Upcoming Service',
      message: 'Your service starts in 2 hours. Professional will arrive soon.',
      time: '1 hour ago',
      read: true
    },
    {
      id: 5,
      type: 'booking',
      icon: Star,
      color: 'bg-yellow-500',
      title: 'Rate Your Experience',
      message: 'How was your experience with Michael Brown? Share your feedback.',
      time: '2 hours ago',
      read: true
    },
    {
      id: 6,
      type: 'payment',
      icon: DollarSign,
      color: 'bg-green-500',
      title: 'Refund Processed',
      message: '₹500 refunded to your account for cancelled booking',
      time: '1 day ago',
      read: true
    },
    {
      id: 7,
      type: 'booking',
      icon: AlertCircle,
      color: 'bg-red-500',
      title: 'Booking Cancelled',
      message: 'Your booking for May 18 has been cancelled by the professional',
      time: '2 days ago',
      read: true
    },
    {
      id: 8,
      type: 'message',
      icon: MessageCircle,
      color: 'bg-purple-500',
      title: 'Special Offer',
      message: 'Get 20% off on your next booking. Use code: HHCS20',
      time: '3 days ago',
      read: true
    }
  ];

  const filteredNotifications = notifications.filter((notif) => {
    if (filter === 'all') return true;
    if (filter === 'bookings') return notif.type === 'booking';
    if (filter === 'payments') return notif.type === 'payment';
    if (filter === 'messages') return notif.type === 'message';
    return true;
  });

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-[#F5F7FA] pb-20">
      <div className="bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white p-6">
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center"
          >
            <X className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold">Notifications</h1>
          <button className="text-sm font-semibold">Mark All Read</button>
        </div>

        {unreadCount > 0 && (
          <div className="bg-white/20 backdrop-blur-sm rounded-2xl px-4 py-3">
            <p className="text-sm">
              You have <span className="font-bold">{unreadCount} unread</span> notifications
            </p>
          </div>
        )}
      </div>

      <div className="p-6 space-y-6">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {[
            { id: 'all', label: 'All', icon: Bell },
            { id: 'bookings', label: 'Bookings', icon: Calendar },
            { id: 'payments', label: 'Payments', icon: DollarSign },
            { id: 'messages', label: 'Messages', icon: MessageCircle }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id as any)}
              className={`flex items-center gap-2 px-5 py-3 rounded-xl font-semibold whitespace-nowrap transition-all ${
                filter === tab.id
                  ? 'bg-[#0A84FF] text-white'
                  : 'bg-white text-gray-700'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              {tab.label}
            </button>
          ))}
        </div>

        <div className="space-y-3">
          {filteredNotifications.length === 0 ? (
            <div className="bg-white rounded-2xl p-12 text-center">
              <Bell className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-800 mb-2">No Notifications</h3>
              <p className="text-gray-600">You're all caught up!</p>
            </div>
          ) : (
            filteredNotifications.map((notification) => {
              const Icon = notification.icon;
              return (
                <button
                  key={notification.id}
                  onClick={notification.action}
                  className={`w-full bg-white rounded-2xl p-5 shadow-md text-left transition-all hover:shadow-lg ${
                    !notification.read ? 'ring-2 ring-[#0A84FF]' : ''
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className={`w-12 h-12 ${notification.color} rounded-xl flex items-center justify-center flex-shrink-0`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h3 className={`font-bold text-gray-800 ${!notification.read ? 'text-[#0A84FF]' : ''}`}>
                          {notification.title}
                        </h3>
                        {!notification.read && (
                          <div className="w-2 h-2 bg-[#0A84FF] rounded-full flex-shrink-0 mt-2" />
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mb-2 line-clamp-2">
                        {notification.message}
                      </p>
                      <p className="text-xs text-gray-500">{notification.time}</p>
                    </div>

                    {notification.action && (
                      <ChevronRight className="w-5 h-5 text-gray-400 flex-shrink-0 mt-3" />
                    )}
                  </div>
                </button>
              );
            })
          )}
        </div>

        {filteredNotifications.length > 0 && (
          <div className="text-center py-4">
            <p className="text-gray-500 text-sm">That's all for now!</p>
          </div>
        )}
      </div>
    </div>
  );
}
