import { useState } from 'react';
import { Home, DollarSign, User, Bell, Clock, FileText, Syringe, Activity, Star } from 'lucide-react';

export default function NurseDashboard() {
  const [activeTab, setActiveTab] = useState('home');

  const shifts = [
    {
      id: 1,
      patient: 'Mrs. Anderson',
      time: '8:00 AM - 4:00 PM',
      tasks: ['Medication', 'Vital Signs', 'Wound Care'],
      status: 'ongoing',
      payment: '₹3,200'
    },
    {
      id: 2,
      patient: 'Mr. Thompson',
      time: '4:00 PM - 12:00 AM',
      tasks: ['IV Monitoring', 'Reports'],
      status: 'upcoming',
      payment: '₹3,500'
    }
  ];

  return (
    <div className="min-h-screen bg-[#F5F7FA] pb-20">
      {activeTab === 'home' && (
        <div className="p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-800">Nurse Dashboard</h1>
              <p className="text-gray-600">Today's Schedule</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-[#0A84FF] to-[#0066CC] rounded-2xl flex items-center justify-center shadow-lg text-2xl">
              👩‍⚕️
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-[#0A84FF] to-[#0066CC] rounded-2xl p-5 text-white shadow-lg">
              <Activity className="w-8 h-8 mb-2" />
              <p className="text-sm opacity-90">Active Patients</p>
              <p className="text-2xl font-bold">8</p>
            </div>
            <div className="bg-gradient-to-br from-[#34C759] to-[#28A745] rounded-2xl p-5 text-white shadow-lg">
              <DollarSign className="w-8 h-8 mb-2" />
              <p className="text-sm opacity-90">Today's Earnings</p>
              <p className="text-2xl font-bold">₹6,700</p>
            </div>
          </div>

          <div>
            <h2 className="text-xl font-bold text-gray-800 mb-4">Today's Shifts</h2>
            <div className="space-y-4">
              {shifts.map((shift) => (
                <div key={shift.id} className="bg-white rounded-2xl p-5 shadow-md">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-bold text-gray-800 text-lg">{shift.patient}</h3>
                      <div className="flex items-center gap-2 text-sm text-gray-600 mt-1">
                        <Clock className="w-4 h-4" />
                        <span>{shift.time}</span>
                      </div>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      shift.status === 'ongoing'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-blue-100 text-blue-700'
                    }`}>
                      {shift.status}
                    </span>
                  </div>

                  <div className="mb-3">
                    <p className="text-sm text-gray-600 mb-2">Medical Tasks:</p>
                    <div className="flex flex-wrap gap-2">
                      {shift.tasks.map((task, index) => (
                        <span key={index} className="bg-blue-50 text-[#0A84FF] px-3 py-1 rounded-lg text-xs font-semibold">
                          {task}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                    <span className="text-[#34C759] font-bold">{shift.payment}</span>
                    <button className="bg-[#0A84FF] text-white px-6 py-2 rounded-lg font-semibold">
                      View Details
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl p-5 shadow-md">
            <h3 className="font-bold text-gray-800 mb-4">Quick Actions</h3>
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: 'Upload Report', icon: FileText, color: 'from-[#0A84FF] to-[#0066CC]' },
                { label: 'Mark Medication', icon: Syringe, color: 'from-[#34C759] to-[#28A745]' },
                { label: 'Vital Signs', icon: Activity, color: 'from-[#FF9500] to-[#FF6B00]' },
                { label: 'Emergency', icon: Bell, color: 'from-[#FF3B30] to-[#CC2E26]' },
              ].map((action, index) => (
                <button
                  key={index}
                  className={`bg-gradient-to-br ${action.color} text-white p-4 rounded-xl flex flex-col items-center gap-2 shadow-md`}
                >
                  <action.icon className="w-6 h-6" />
                  <span className="text-sm font-semibold">{action.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'earnings' && (
        <div className="p-6 space-y-6">
          <h1 className="text-2xl font-bold text-gray-800">Earnings</h1>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white rounded-2xl p-5 shadow-md">
              <p className="text-sm text-gray-600 mb-1">This Week</p>
              <p className="text-2xl font-bold text-gray-800">₹28,500</p>
            </div>
            <div className="bg-white rounded-2xl p-5 shadow-md">
              <p className="text-sm text-gray-600 mb-1">This Month</p>
              <p className="text-2xl font-bold text-gray-800">₹1,15,000</p>
            </div>
          </div>

          <div className="bg-gradient-to-br from-[#34C759] to-[#28A745] rounded-2xl p-6 text-white shadow-lg">
            <p className="text-sm opacity-90 mb-2">Available Balance</p>
            <p className="text-3xl font-bold mb-4">₹95,000</p>
            <button className="w-full bg-white text-[#34C759] py-3 rounded-xl font-semibold">
              Withdraw Earnings
            </button>
          </div>
        </div>
      )}

      {activeTab === 'profile' && (
        <div className="p-6 space-y-6">
          <div className="bg-white rounded-2xl p-6 shadow-md">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-20 h-20 bg-gradient-to-br from-[#0A84FF] to-[#0066CC] rounded-2xl flex items-center justify-center text-3xl">
                👩‍⚕️
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-800">Sarah Johnson</h2>
                <p className="text-gray-600">Registered Nurse (GNM)</p>
                <div className="flex items-center gap-1 mt-1">
                  <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                  <span className="font-semibold text-gray-800">4.8</span>
                  <span className="text-gray-500 text-sm">(89 reviews)</span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-md">
            <h3 className="font-bold text-gray-800 mb-4">Certifications</h3>
            <div className="space-y-3">
              {[
                { name: 'GNM Certificate', status: 'verified' },
                { name: 'Aadhaar Card', status: 'verified' },
                { name: 'Bank Details', status: 'verified' },
              ].map((doc, index) => (
                <div key={index} className="flex items-center justify-between py-3 border-b border-gray-100">
                  <span className="text-gray-800">{doc.name}</span>
                  <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-semibold">
                    {doc.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-4">
        <div className="flex items-center justify-around max-w-md mx-auto">
          {[
            { id: 'home', icon: Home, label: 'Home' },
            { id: 'earnings', icon: DollarSign, label: 'Earnings' },
            { id: 'notifications', icon: Bell, label: 'Alerts' },
            { id: 'profile', icon: User, label: 'Profile' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center gap-1 ${
                activeTab === tab.id ? 'text-[#0A84FF]' : 'text-gray-400'
              }`}
            >
              <tab.icon className="w-6 h-6" />
              <span className="text-xs">{tab.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
