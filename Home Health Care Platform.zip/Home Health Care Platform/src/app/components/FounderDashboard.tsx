import { useState } from 'react';
import {
  Users, DollarSign, Calendar, TrendingUp, UserCheck, FileCheck,
  Bell, Settings, BarChart3, PieChart, Activity, Shield,
  CheckCircle, Clock, XCircle, Mail, Phone
} from 'lucide-react';

export default function FounderDashboard() {
  const [activeTab, setActiveTab] = useState('overview');

  const stats = {
    totalUsers: 15234,
    totalBookings: 8567,
    totalEarnings: '₹45,67,890',
    companyProfit: '₹10,50,615',
    activeStaff: 1245,
    pendingVerifications: 23
  };

  const recentBookings = [
    { id: 1, client: 'John Doe', service: 'Caretaker', amount: '₹2,500', status: 'completed', profit: '₹575' },
    { id: 2, client: 'Sarah Smith', service: 'Nurse', amount: '₹3,800', status: 'ongoing', profit: '₹874' },
    { id: 3, client: 'Mike Johnson', service: 'Doctor', amount: '₹1,500', status: 'completed', profit: '₹345' },
  ];

  const pendingVerifications = [
    { id: 1, name: 'Dr. Amit Kumar', role: 'Doctor', document: 'MBBS Certificate', submitted: '2 hours ago' },
    { id: 2, name: 'Priya Sharma', role: 'Nurse', document: 'GNM Certificate', submitted: '5 hours ago' },
    { id: 3, name: 'Raj Patel', role: 'Caretaker', document: 'Aadhaar Card', submitted: '1 day ago' },
  ];

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      <div className="bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white p-6 pb-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold mb-2">Founder Dashboard</h1>
              <p className="text-blue-100">HHCS - Home Health Care Service</p>
            </div>
            <button className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
              <Settings className="w-6 h-6" />
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-5">
              <Users className="w-8 h-8 mb-2" />
              <p className="text-sm text-blue-100">Total Users</p>
              <p className="text-2xl font-bold">{stats.totalUsers.toLocaleString()}</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-5">
              <Calendar className="w-8 h-8 mb-2" />
              <p className="text-sm text-blue-100">Total Bookings</p>
              <p className="text-2xl font-bold">{stats.totalBookings.toLocaleString()}</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-5">
              <DollarSign className="w-8 h-8 mb-2" />
              <p className="text-sm text-blue-100">Total Revenue</p>
              <p className="text-2xl font-bold">{stats.totalEarnings}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6 -mt-4">
        <div className="flex gap-2 mb-6 bg-white rounded-2xl p-2 shadow-md">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'profit', label: 'Profit', icon: DollarSign },
            { id: 'verification', label: 'Verification', icon: FileCheck },
            { id: 'founder', label: 'Founder', icon: Shield }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-semibold transition-all ${
                activeTab === tab.id
                  ? 'bg-[#0A84FF] text-white'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              <span className="hidden md:inline">{tab.label}</span>
            </button>
          ))}
        </div>

        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl p-6 shadow-md">
                <h3 className="font-bold text-gray-800 mb-4">Recent Bookings</h3>
                <div className="space-y-3">
                  {recentBookings.map((booking) => (
                    <div key={booking.id} className="flex items-center justify-between py-3 border-b border-gray-100">
                      <div>
                        <p className="font-semibold text-gray-800">{booking.client}</p>
                        <p className="text-sm text-gray-600">{booking.service}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-gray-800">{booking.amount}</p>
                        <p className="text-xs text-[#34C759]">Profit: {booking.profit}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-md">
                <h3 className="font-bold text-gray-800 mb-4">Staff Statistics</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Active Caretakers</span>
                    <span className="font-bold text-gray-800">856</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Active Nurses</span>
                    <span className="font-bold text-gray-800">245</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Active Doctors</span>
                    <span className="font-bold text-gray-800">144</span>
                  </div>
                  <div className="pt-4 border-t border-gray-200">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-gray-800">Total Active Staff</span>
                      <span className="font-bold text-[#0A84FF] text-xl">{stats.activeStaff}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-2xl p-6 shadow-md">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-[#FF9500] to-[#FF6B00] rounded-2xl flex items-center justify-center">
                  <Bell className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-800 text-lg">Pending Actions</h3>
                  <p className="text-gray-600">{stats.pendingVerifications} verifications waiting</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'profit' && (
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-[#34C759] to-[#28A745] rounded-3xl p-8 text-white shadow-xl">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <p className="text-green-100 mb-2">Company Profit (23%)</p>
                  <h2 className="text-4xl font-bold mb-2">{stats.companyProfit}</h2>
                  <p className="text-green-100">Available for withdrawal</p>
                </div>
                <DollarSign className="w-12 h-12" />
              </div>
              <button className="w-full bg-white text-[#34C759] py-4 rounded-xl font-semibold shadow-lg">
                Withdraw Profit
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white rounded-2xl p-6 shadow-md">
                <p className="text-gray-600 mb-2">Daily Profit</p>
                <p className="text-2xl font-bold text-gray-800">₹45,678</p>
                <div className="flex items-center gap-1 mt-2 text-[#34C759]">
                  <TrendingUp className="w-4 h-4" />
                  <span className="text-sm">+12.5%</span>
                </div>
              </div>
              <div className="bg-white rounded-2xl p-6 shadow-md">
                <p className="text-gray-600 mb-2">Weekly Profit</p>
                <p className="text-2xl font-bold text-gray-800">₹3,45,890</p>
                <div className="flex items-center gap-1 mt-2 text-[#34C759]">
                  <TrendingUp className="w-4 h-4" />
                  <span className="text-sm">+8.3%</span>
                </div>
              </div>
              <div className="bg-white rounded-2xl p-6 shadow-md">
                <p className="text-gray-600 mb-2">Monthly Profit</p>
                <p className="text-2xl font-bold text-gray-800">₹14,56,780</p>
                <div className="flex items-center gap-1 mt-2 text-[#34C759]">
                  <TrendingUp className="w-4 h-4" />
                  <span className="text-sm">+15.7%</span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-md">
              <h3 className="font-bold text-gray-800 mb-4">Profit Breakdown</h3>
              <div className="space-y-4">
                {[
                  { service: 'Caretaker Services', revenue: '₹28,50,000', profit: '₹6,55,500', percentage: 23 },
                  { service: 'Nursing Services', revenue: '₹15,20,000', profit: '₹3,49,600', percentage: 23 },
                  { service: 'Doctor Consultations', revenue: '₹8,90,000', profit: '₹2,04,700', percentage: 23 },
                ].map((item, index) => (
                  <div key={index} className="border-b border-gray-100 pb-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold text-gray-800">{item.service}</span>
                      <span className="text-[#34C759] font-bold">{item.profit}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm text-gray-600">
                      <span>Total Revenue: {item.revenue}</span>
                      <span>Margin: {item.percentage}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'verification' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white rounded-2xl p-5 shadow-md">
                <div className="flex items-center gap-3 mb-2">
                  <Clock className="w-6 h-6 text-yellow-500" />
                  <p className="text-gray-600">Pending</p>
                </div>
                <p className="text-3xl font-bold text-gray-800">{stats.pendingVerifications}</p>
              </div>
              <div className="bg-white rounded-2xl p-5 shadow-md">
                <div className="flex items-center gap-3 mb-2">
                  <CheckCircle className="w-6 h-6 text-green-500" />
                  <p className="text-gray-600">Verified</p>
                </div>
                <p className="text-3xl font-bold text-gray-800">1,245</p>
              </div>
              <div className="bg-white rounded-2xl p-5 shadow-md">
                <div className="flex items-center gap-3 mb-2">
                  <XCircle className="w-6 h-6 text-red-500" />
                  <p className="text-gray-600">Rejected</p>
                </div>
                <p className="text-3xl font-bold text-gray-800">56</p>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-md">
              <h3 className="font-bold text-gray-800 mb-4">Pending Verifications</h3>
              <div className="space-y-4">
                {pendingVerifications.map((verification) => (
                  <div key={verification.id} className="border border-gray-200 rounded-xl p-5">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-bold text-gray-800">{verification.name}</h4>
                        <p className="text-sm text-gray-600">{verification.role}</p>
                        <p className="text-sm text-gray-500 mt-1">{verification.document}</p>
                      </div>
                      <span className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-xs font-semibold">
                        Pending
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mb-3">Submitted {verification.submitted}</p>
                    <div className="flex gap-3">
                      <button className="flex-1 bg-[#34C759] text-white py-3 rounded-xl font-semibold">
                        Approve
                      </button>
                      <button className="flex-1 bg-[#FF3B30] text-white py-3 rounded-xl font-semibold">
                        Reject
                      </button>
                      <button className="px-4 bg-gray-100 rounded-xl text-gray-700 font-semibold">
                        View Docs
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'founder' && (
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-3xl p-8 shadow-md">
              <div className="flex items-start gap-6">
                <div className="w-24 h-24 bg-gradient-to-br from-[#0A84FF] to-[#34C759] rounded-3xl flex items-center justify-center text-4xl shadow-xl flex-shrink-0">
                  👨‍💼
                </div>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-gray-800 mb-2">Bittu Yadav</h2>
                  <p className="text-lg text-gray-700 font-semibold mb-1">Founder & CEO - HHCS</p>
                  <p className="text-gray-600 mb-4">HOME HEALTH CARE SERVICE</p>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-gray-700">
                      <Phone className="w-4 h-4 text-[#0A84FF]" />
                      <span>+91 9430535047</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-700">
                      <Mail className="w-4 h-4 text-[#0A84FF]" />
                      <span className="text-sm">bittukumaryadav911765@gmail.com</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-700">
                      <UserCheck className="w-4 h-4 text-[#0A84FF]" />
                      <span>YADAV_BITTU_BR25</span>
                    </div>
                  </div>

                  <div className="bg-white rounded-2xl p-5 mb-4">
                    <h3 className="font-semibold text-gray-800 mb-2">Mission</h3>
                    <p className="text-gray-600">
                      Providing trusted healthcare service at home.
                    </p>
                  </div>

                  <div className="bg-white rounded-2xl p-5 mb-4">
                    <h3 className="font-semibold text-gray-800 mb-2">Core Values</h3>
                    <p className="text-gray-600">
                      Service, trust, safety, and humanity.
                    </p>
                  </div>

                  <div className="bg-gradient-to-r from-[#0A84FF] to-[#0066CC] rounded-2xl p-5 text-white text-center">
                    <p className="text-lg font-semibold italic">SEVA PARMO DHARMAH</p>
                    <p className="text-lg font-semibold italic">DHARMO RAKSHATI RAKSHATAH</p>
                  </div>
                </div>
              </div>
            </div>

            <button className="w-full bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white py-4 rounded-2xl font-semibold shadow-lg">
              Contact Founder
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
