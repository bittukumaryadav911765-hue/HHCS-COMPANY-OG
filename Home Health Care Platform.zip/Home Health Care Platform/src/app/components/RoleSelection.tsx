import { User, Heart, Stethoscope, UserCog, ArrowRight } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function RoleSelection() {
  const [selectedRole, setSelectedRole] = useState<string>('');
  const navigate = useNavigate();

  const roles = [
    {
      id: 'client',
      title: 'CLIENT / CUSTOMER',
      description: 'Book trusted healthcare services at home',
      icon: User,
      gradient: 'from-[#0A84FF] to-[#0066CC]',
      size: 'large',
      priority: 'Highest Priority & Premium Experience'
    },
    {
      id: 'caretaker',
      title: 'CARETAKER',
      description: 'Provide essential care and support',
      icon: Heart,
      gradient: 'from-[#34C759] to-[#28A745]',
      size: 'medium',
      priority: 'Main Workforce & Trusted Support'
    },
    {
      id: 'nurse',
      title: 'NURSE',
      description: 'Deliver medical assistance and care',
      icon: Stethoscope,
      gradient: 'from-[#FF9500] to-[#FF6B00]',
      size: 'medium',
      priority: 'Medical Assistance Role'
    },
    {
      id: 'doctor',
      title: 'DOCTOR',
      description: 'Provide consultation and supervision',
      icon: UserCog,
      gradient: 'from-[#AF52DE] to-[#9933CC]',
      size: 'small',
      priority: 'Consultation & Supervision'
    }
  ];

  const handleContinue = () => {
    if (selectedRole) {
      navigate(`/register/${selectedRole}`);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 p-6">
      <div className="max-w-4xl mx-auto py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Select Your Role</h1>
          <p className="text-gray-600">Choose how you want to use HHCS</p>
        </div>

        <div className="space-y-4">
          {roles.map((role) => (
            <button
              key={role.id}
              onClick={() => setSelectedRole(role.id)}
              className={`w-full bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all border-2 ${
                selectedRole === role.id ? 'border-[#0A84FF]' : 'border-transparent'
              } ${role.size === 'large' ? 'py-8' : role.size === 'medium' ? 'py-6' : 'py-5'}`}
            >
              <div className="flex items-center gap-6">
                <div className={`w-16 h-16 bg-gradient-to-br ${role.gradient} rounded-2xl flex items-center justify-center shadow-lg flex-shrink-0`}>
                  <role.icon className="w-8 h-8 text-white" strokeWidth={2} />
                </div>
                <div className="flex-1 text-left">
                  <h3 className="text-lg font-bold text-gray-800 mb-1">{role.title}</h3>
                  <p className="text-sm text-gray-600 mb-2">{role.description}</p>
                  <p className="text-xs text-[#0A84FF] font-medium">{role.priority}</p>
                </div>
                {selectedRole === role.id && (
                  <div className="w-6 h-6 bg-[#0A84FF] rounded-full flex items-center justify-center">
                    <ArrowRight className="w-4 h-4 text-white" />
                  </div>
                )}
              </div>
            </button>
          ))}
        </div>

        <button
          onClick={handleContinue}
          disabled={!selectedRole}
          className={`w-full mt-8 py-4 rounded-2xl font-semibold shadow-lg transition-all ${
            selectedRole
              ? 'bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white hover:shadow-xl'
              : 'bg-gray-200 text-gray-400 cursor-not-allowed'
          }`}
        >
          Continue
        </button>

        <button
          onClick={() => navigate('/login')}
          className="w-full mt-4 py-4 text-gray-600 hover:text-[#0A84FF] transition-colors"
        >
          Already have an account? Login
        </button>
      </div>
    </div>
  );
}
