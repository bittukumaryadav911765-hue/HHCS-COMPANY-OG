import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Calendar, Clock, MapPin, Star, Phone, MessageCircle,
  CreditCard, CheckCircle, User, ChevronRight, X, Filter
} from 'lucide-react';

export default function BookingFlow() {
  const { service } = useParams<{ service: string }>();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [selectedStaff, setSelectedStaff] = useState<any>(null);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('upi');

  const serviceDetails: any = {
    caretaker: {
      name: 'Caretaker Service',
      icon: '👨‍⚕️',
      color: 'from-[#34C759] to-[#28A745]',
      basePrice: 2500
    },
    nurse: {
      name: 'Nursing Service',
      icon: '👩‍⚕️',
      color: 'from-[#0A84FF] to-[#0066CC]',
      basePrice: 3500
    },
    doctor: {
      name: 'Doctor Consultation',
      icon: '👨‍⚕️',
      color: 'from-[#AF52DE] to-[#9933CC]',
      basePrice: 1500
    },
    physiotherapy: {
      name: 'Physiotherapy',
      icon: '🏋️',
      color: 'from-[#FF9500] to-[#FF6B00]',
      basePrice: 2000
    },
    icu: {
      name: 'ICU Setup',
      icon: '🏥',
      color: 'from-[#FF3B30] to-[#CC2E26]',
      basePrice: 15000
    },
    'elder-care': {
      name: 'Elder Care',
      icon: '👴',
      color: 'from-[#5AC8FA] to-[#0098DB]',
      basePrice: 2800
    },
    rehabilitation: {
      name: 'Rehabilitation',
      icon: '🩺',
      color: 'from-[#FF2D55] to-[#CC2444]',
      basePrice: 3200
    },
    injection: {
      name: 'Home Injection',
      icon: '💉',
      color: 'from-[#34C759] to-[#28A745]',
      basePrice: 500
    }
  };

  const currentService = serviceDetails[service as string] || serviceDetails.caretaker;

  const availableStaff = [
    {
      id: 1,
      name: 'Sarah Johnson',
      rating: 4.9,
      reviews: 156,
      experience: '8 years',
      distance: '2.3 km',
      price: currentService.basePrice,
      avatar: '👩‍⚕️',
      specialization: 'Elder Care Specialist',
      verified: true
    },
    {
      id: 2,
      name: 'Michael Brown',
      rating: 4.8,
      reviews: 124,
      experience: '6 years',
      distance: '3.1 km',
      price: currentService.basePrice - 200,
      avatar: '👨‍⚕️',
      specialization: 'General Care',
      verified: true
    },
    {
      id: 3,
      name: 'Priya Sharma',
      rating: 4.9,
      reviews: 189,
      experience: '10 years',
      distance: '1.8 km',
      price: currentService.basePrice + 300,
      avatar: '👩‍⚕️',
      specialization: 'Critical Care Expert',
      verified: true
    }
  ];

  const timeSlots = [
    '08:00 AM', '09:00 AM', '10:00 AM', '11:00 AM',
    '12:00 PM', '01:00 PM', '02:00 PM', '03:00 PM',
    '04:00 PM', '05:00 PM', '06:00 PM', '07:00 PM'
  ];

  const handleBooking = () => {
    navigate('/booking-confirmation', {
      state: {
        service: currentService,
        staff: selectedStaff,
        date: selectedDate,
        time: selectedTime,
        payment: paymentMethod
      }
    });
  };

  return (
    <div className="min-h-screen bg-[#F5F7FA] pb-20">
      <div className="bg-gradient-to-r from-[#0A84FF] to-[#0066CC] text-white p-6">
        <div className="flex items-center gap-4 mb-4">
          <button onClick={() => navigate(-1)} className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
            <X className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-2xl font-bold">Book {currentService.name}</h1>
            <p className="text-blue-100 text-sm">Step {step} of 3</p>
          </div>
        </div>

        <div className="flex gap-2">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={`flex-1 h-2 rounded-full ${
                s <= step ? 'bg-white' : 'bg-white/30'
              }`}
            />
          ))}
        </div>
      </div>

      <div className="p-6 space-y-6">
        {step === 1 && (
          <>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-gray-800">Select Professional</h2>
              <button className="flex items-center gap-2 text-[#0A84FF] font-semibold">
                <Filter className="w-5 h-5" />
                Filter
              </button>
            </div>

            <div className="space-y-4">
              {availableStaff.map((staff) => (
                <div
                  key={staff.id}
                  onClick={() => setSelectedStaff(staff)}
                  className={`bg-white rounded-2xl p-5 shadow-md cursor-pointer transition-all ${
                    selectedStaff?.id === staff.id ? 'ring-2 ring-[#0A84FF]' : ''
                  }`}
                >
                  <div className="flex items-start gap-4 mb-4">
                    <div className={`w-16 h-16 bg-gradient-to-br ${currentService.color} rounded-2xl flex items-center justify-center text-3xl`}>
                      {staff.avatar}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-bold text-gray-800 text-lg">{staff.name}</h3>
                        {staff.verified && (
                          <CheckCircle className="w-5 h-5 text-green-500" />
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{staff.specialization}</p>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                          <span className="font-semibold">{staff.rating}</span>
                          <span>({staff.reviews})</span>
                        </div>
                        <span>•</span>
                        <span>{staff.experience} exp</span>
                        <span>•</span>
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          <span>{staff.distance}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                    <div>
                      <p className="text-sm text-gray-600">Starting from</p>
                      <p className="text-2xl font-bold text-gray-800">₹{staff.price.toLocaleString()}</p>
                    </div>
                    <div className="flex gap-2">
                      <button className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center">
                        <Phone className="w-5 h-5 text-gray-600" />
                      </button>
                      <button className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center">
                        <MessageCircle className="w-5 h-5 text-gray-600" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => setStep(2)}
              disabled={!selectedStaff}
              className={`w-full py-4 rounded-2xl font-semibold shadow-lg transition-all ${
                selectedStaff
                  ? `bg-gradient-to-r ${currentService.color} text-white`
                  : 'bg-gray-200 text-gray-400 cursor-not-allowed'
              }`}
            >
              Continue
            </button>
          </>
        )}

        {step === 2 && (
          <>
            <h2 className="text-xl font-bold text-gray-800 mb-4">Select Date & Time</h2>

            <div className="bg-white rounded-2xl p-6 shadow-md mb-6">
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                Select Date
              </label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                className="w-full px-4 py-4 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0A84FF]"
              />
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-md">
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                Select Time Slot
              </label>
              <div className="grid grid-cols-3 gap-3">
                {timeSlots.map((time) => (
                  <button
                    key={time}
                    onClick={() => setSelectedTime(time)}
                    className={`py-3 rounded-xl font-semibold transition-all ${
                      selectedTime === time
                        ? `bg-gradient-to-r ${currentService.color} text-white`
                        : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    {time}
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-5">
              <div className="flex items-center gap-3">
                <Clock className="w-6 h-6 text-[#0A84FF]" />
                <div>
                  <p className="font-semibold text-gray-800">Estimated Duration</p>
                  <p className="text-sm text-gray-600">8 hours (can be extended)</p>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep(1)}
                className="flex-1 bg-gray-100 text-gray-700 py-4 rounded-xl font-semibold"
              >
                Back
              </button>
              <button
                onClick={() => setStep(3)}
                disabled={!selectedDate || !selectedTime}
                className={`flex-1 py-4 rounded-2xl font-semibold shadow-lg transition-all ${
                  selectedDate && selectedTime
                    ? `bg-gradient-to-r ${currentService.color} text-white`
                    : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                }`}
              >
                Continue
              </button>
            </div>
          </>
        )}

        {step === 3 && selectedStaff && (
          <>
            <h2 className="text-xl font-bold text-gray-800 mb-4">Booking Summary</h2>

            <div className="bg-white rounded-2xl p-6 shadow-md mb-6">
              <div className="flex items-center gap-4 mb-4 pb-4 border-b border-gray-100">
                <div className={`w-16 h-16 bg-gradient-to-br ${currentService.color} rounded-2xl flex items-center justify-center text-3xl`}>
                  {selectedStaff.avatar}
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-gray-800">{selectedStaff.name}</h3>
                  <p className="text-sm text-gray-600">{currentService.name}</p>
                </div>
              </div>

              <div className="space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-gray-600">
                    <Calendar className="w-4 h-4" />
                    <span>Date</span>
                  </div>
                  <span className="font-semibold text-gray-800">
                    {new Date(selectedDate).toLocaleDateString('en-IN', {
                      weekday: 'short',
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric'
                    })}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-gray-600">
                    <Clock className="w-4 h-4" />
                    <span>Time</span>
                  </div>
                  <span className="font-semibold text-gray-800">{selectedTime}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-gray-600">
                    <MapPin className="w-4 h-4" />
                    <span>Distance</span>
                  </div>
                  <span className="font-semibold text-gray-800">{selectedStaff.distance}</span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-md mb-6">
              <h3 className="font-bold text-gray-800 mb-4">Payment Details</h3>
              <div className="space-y-3 text-sm mb-4 pb-4 border-b border-gray-100">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Service Charge</span>
                  <span className="font-semibold text-gray-800">₹{selectedStaff.price.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Platform Fee</span>
                  <span className="font-semibold text-gray-800">₹50</span>
                </div>
                <div className="flex items-center justify-between text-green-600">
                  <span>Discount</span>
                  <span className="font-semibold">-₹100</span>
                </div>
              </div>
              <div className="flex items-center justify-between text-lg">
                <span className="font-bold text-gray-800">Total Amount</span>
                <span className="font-bold text-[#0A84FF]">₹{(selectedStaff.price - 50).toLocaleString()}</span>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-md mb-6">
              <h3 className="font-bold text-gray-800 mb-4">Payment Method</h3>
              <div className="space-y-3">
                {[
                  { id: 'upi', label: 'UPI (Google Pay, PhonePe, Paytm)', icon: CreditCard },
                  { id: 'card', label: 'Debit/Credit Card', icon: CreditCard },
                  { id: 'netbanking', label: 'Net Banking', icon: CreditCard }
                ].map((method) => (
                  <button
                    key={method.id}
                    onClick={() => setPaymentMethod(method.id)}
                    className={`w-full flex items-center gap-3 p-4 rounded-xl border-2 transition-all ${
                      paymentMethod === method.id
                        ? 'border-[#0A84FF] bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                      paymentMethod === method.id ? 'bg-[#0A84FF]' : 'bg-gray-100'
                    }`}>
                      <method.icon className={`w-5 h-5 ${
                        paymentMethod === method.id ? 'text-white' : 'text-gray-600'
                      }`} />
                    </div>
                    <span className="font-semibold text-gray-800">{method.label}</span>
                    {paymentMethod === method.id && (
                      <CheckCircle className="w-5 h-5 text-[#0A84FF] ml-auto" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-5 mb-6">
              <p className="text-sm text-gray-700">
                <strong>Note:</strong> Payment will be processed securely. You can cancel free of charge up to 2 hours before the scheduled time.
              </p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep(2)}
                className="flex-1 bg-gray-100 text-gray-700 py-4 rounded-xl font-semibold"
              >
                Back
              </button>
              <button
                onClick={handleBooking}
                className={`flex-1 bg-gradient-to-r ${currentService.color} text-white py-4 rounded-2xl font-semibold shadow-lg flex items-center justify-center gap-2`}
              >
                Confirm & Pay
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
