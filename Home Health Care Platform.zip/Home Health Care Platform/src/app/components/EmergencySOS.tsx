import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertCircle, Phone, MapPin, Clock, User, X, CheckCircle } from 'lucide-react';

export default function EmergencySOS() {
  const navigate = useNavigate();
  const [countdown, setCountdown] = useState(10);
  const [activated, setActivated] = useState(false);
  const [cancelled, setCancelled] = useState(false);

  useEffect(() => {
    if (countdown > 0 && !cancelled && !activated) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else if (countdown === 0 && !cancelled) {
      setActivated(true);
    }
  }, [countdown, cancelled, activated]);

  const handleCancel = () => {
    setCancelled(true);
    setTimeout(() => navigate(-1), 1500);
  };

  if (cancelled) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 flex items-center justify-center p-6">
        <div className="text-center">
          <div className="w-24 h-24 bg-green-500 rounded-full mx-auto mb-6 flex items-center justify-center">
            <CheckCircle className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800 mb-2">SOS Cancelled</h1>
          <p className="text-gray-600">Emergency alert has been cancelled</p>
        </div>
      </div>
    );
  }

  if (activated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-500 to-red-600 flex items-center justify-center p-6">
        <div className="text-center text-white">
          <div className="w-32 h-32 bg-white rounded-full mx-auto mb-8 flex items-center justify-center animate-pulse">
            <AlertCircle className="w-16 h-16 text-red-500" />
          </div>
          <h1 className="text-3xl font-bold mb-4">Emergency Alert Activated!</h1>
          <p className="text-xl mb-8">Help is on the way</p>

          <div className="bg-white/20 backdrop-blur-sm rounded-3xl p-6 mb-8">
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-left">
                <Phone className="w-6 h-6" />
                <div>
                  <p className="text-sm opacity-90">Contacting Support</p>
                  <p className="font-bold">+91 9430535047</p>
                </div>
              </div>
              <div className="flex items-center gap-3 text-left">
                <User className="w-6 h-6" />
                <div>
                  <p className="text-sm opacity-90">Notifying Emergency Contact</p>
                  <p className="font-bold">+91 9876543211</p>
                </div>
              </div>
              <div className="flex items-center gap-3 text-left">
                <MapPin className="w-6 h-6" />
                <div>
                  <p className="text-sm opacity-90">Sharing Location</p>
                  <p className="font-bold">123 Green Park, Sector 12</p>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <button
              onClick={() => alert('Calling emergency support...')}
              className="w-full bg-white text-red-500 py-4 rounded-2xl font-bold text-lg shadow-xl"
            >
              Call Support Now
            </button>
            <button
              onClick={() => navigate(-1)}
              className="w-full bg-white/20 backdrop-blur-sm text-white py-4 rounded-2xl font-semibold"
            >
              Back to Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center p-6">
      <div className="text-center text-white max-w-md">
        <div className="relative mb-8">
          <div className="w-40 h-40 bg-white/20 rounded-full mx-auto flex items-center justify-center animate-pulse">
            <div className="w-32 h-32 bg-white/30 rounded-full flex items-center justify-center">
              <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center">
                <span className="text-6xl font-bold text-red-500">{countdown}</span>
              </div>
            </div>
          </div>
        </div>

        <h1 className="text-3xl font-bold mb-4">Emergency SOS</h1>
        <p className="text-xl mb-8">Activating in {countdown} seconds...</p>

        <div className="bg-white/20 backdrop-blur-sm rounded-3xl p-6 mb-8">
          <div className="flex items-start gap-3 mb-4">
            <AlertCircle className="w-6 h-6 flex-shrink-0 mt-1" />
            <div className="text-left">
              <p className="font-semibold mb-2">What will happen:</p>
              <ul className="text-sm space-y-2 opacity-90">
                <li>• 24/7 support team will be notified</li>
                <li>• Your emergency contact will be called</li>
                <li>• Your live location will be shared</li>
                <li>• Nearest healthcare professional will be dispatched</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <button
            onClick={handleCancel}
            className="w-full bg-white text-gray-800 py-5 rounded-2xl font-bold text-lg shadow-xl flex items-center justify-center gap-2"
          >
            <X className="w-6 h-6" />
            Cancel SOS
          </button>
          <button
            onClick={() => {
              setCountdown(0);
              setActivated(true);
            }}
            className="w-full bg-red-600 text-white py-5 rounded-2xl font-bold text-lg shadow-xl border-2 border-white"
          >
            Activate Now
          </button>
        </div>

        <div className="mt-8 text-sm opacity-75">
          <p>False alarms may result in charges</p>
        </div>
      </div>
    </div>
  );
}
