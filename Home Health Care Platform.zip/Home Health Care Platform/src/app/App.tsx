import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import SplashScreen from './components/SplashScreen';
import Onboarding from './components/Onboarding';
import Website from './components/Website';
import RoleSelection from './components/RoleSelection';
import Registration from './components/Registration';
import Login from './components/Login';
import ClientDashboard from './components/ClientDashboard';
import CaretakerDashboard from './components/CaretakerDashboard';
import NurseDashboard from './components/NurseDashboard';
import DoctorDashboard from './components/DoctorDashboard';
import FounderDashboard from './components/FounderDashboard';
import BookingFlow from './components/BookingFlow';
import BookingConfirmation from './components/BookingConfirmation';
import LiveTracking from './components/LiveTracking';
import ChatSystem from './components/ChatSystem';
import Notifications from './components/Notifications';
import ProfileSettings from './components/ProfileSettings';
import EmergencySOS from './components/EmergencySOS';
import ServiceHistory from './components/ServiceHistory';
import WalletPayments from './components/WalletPayments';
import HealthRecords from './components/HealthRecords';
import RewardsLoyalty from './components/RewardsLoyalty';
import AppSettings from './components/AppSettings';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Website />} />
        <Route path="/splash" element={<SplashScreen />} />
        <Route path="/onboarding" element={<Onboarding />} />
        <Route path="/role-selection" element={<RoleSelection />} />
        <Route path="/register/:role" element={<Registration />} />
        <Route path="/login" element={<Login />} />
        <Route path="/founder-login" element={<Login />} />

        <Route path="/client-dashboard" element={<ClientDashboard />} />
        <Route path="/caretaker-dashboard" element={<CaretakerDashboard />} />
        <Route path="/nurse-dashboard" element={<NurseDashboard />} />
        <Route path="/doctor-dashboard" element={<DoctorDashboard />} />
        <Route path="/founder-dashboard" element={<FounderDashboard />} />

        <Route path="/booking/:service" element={<BookingFlow />} />
        <Route path="/booking-confirmation" element={<BookingConfirmation />} />
        <Route path="/live-tracking" element={<LiveTracking />} />
        <Route path="/chat" element={<ChatSystem />} />
        <Route path="/notifications" element={<Notifications />} />
        <Route path="/profile-settings" element={<ProfileSettings />} />
        <Route path="/emergency-sos" element={<EmergencySOS />} />
        <Route path="/service-history" element={<ServiceHistory />} />
        <Route path="/wallet" element={<WalletPayments />} />
        <Route path="/health-records" element={<HealthRecords />} />
        <Route path="/rewards" element={<RewardsLoyalty />} />
        <Route path="/app-settings" element={<AppSettings />} />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}