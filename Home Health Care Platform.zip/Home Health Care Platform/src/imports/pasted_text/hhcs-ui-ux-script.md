HHCS — HOME HEALTH CARE SERVICE
FINAL MASTER UI/UX SCRIPT
(ULTIMATE FIGMA MAKE PROMPT)

Create a complete premium hospital-style healthcare ecosystem platform named:

“HHCS — HOME HEALTH CARE SERVICE”

Founder:
Bittu Yadav

Tagline:
SEVA PARMO DHARMAH
DHARMO RAKSHATI RAKSHATAH

====================================================
MAIN GOAL
====================================================

Create:
1. Modern mobile healthcare app
2. Responsive website
3. Founder admin panel
4. Multi-role healthcare ecosystem

The UI must feel:
- Premium
- Trustworthy
- Comfortable
- Modern hospital style
- Emotionally safe
- Clean and professional

The design should look like a real healthcare startup product.

====================================================
DESIGN STYLE
====================================================

Theme:
Modern hospital dashboard UI

Use:
- White background
- Soft medical blue gradients
- Healthcare green accents
- Rounded modern cards
- Soft shadows
- Smooth spacing
- Comfortable typography
- Premium medical icons
- Glassmorphism effects
- Minimal clean layout

Primary Color:
#0A84FF

Secondary Color:
#34C759

Background:
#F5F7FA

Danger:
#FF3B30

Font:
Poppins / Inter

Animation Feel:
Smooth, modern, premium

====================================================
USER PRIORITY SYSTEM
====================================================

1. CLIENT / CUSTOMER
Highest priority and premium experience

2. CARETAKER
Main workforce and trusted support

3. NURSE
Medical assistance role

4. DOCTOR
Consultation and supervision

5. FOUNDER ADMIN
System management

====================================================
APP FLOW
====================================================

1. SPLASH SCREEN

Center Logo:
HHCS

Tagline:
Trusted Home Health Care Service

Buttons:
- Login
- Register

Background:
Blurred hospital environment

Bottom text:
Secure • Verified • Trusted

====================================================

2. ONBOARDING SCREENS

Screen 1:
Home healthcare at your doorstep

Screen 2:
Verified caretakers and nurses

Screen 3:
Emergency and live support anytime

Button:
Get Started

====================================================

3. ROLE SELECTION SCREEN

Large highlighted CLIENT card

Medium CARETAKER card

Medium NURSE card

Small DOCTOR card

Each card contains:
- icon
- short description
- clean hospital look

Bottom:
Continue button

====================================================

4. LOGIN SCREEN

Fields:
- Mobile or Email
- Password
- Demo OTP

Buttons:
- Login
- Forgot Password

Option:
Login as Founder Admin

====================================================

5. REGISTRATION FLOW

COMMON FIELDS:
- Full Name
- Mobile Number
- Email ID
- OTP Verification
- Address
- Password
- Confirm Password
- Profile Photo Upload

====================================================

CLIENT REGISTRATION

Features:
- Live location permission
- Emergency contact
- Online payment setup

====================================================

CARETAKER REGISTRATION

Required:
- 10th certificate upload
- Aadhaar upload
- Selfie verification
- Bank/UPI verification

====================================================

NURSE REGISTRATION

Required:
- ANM
- GNM
- BSc Nursing
- MSc Nursing
- Aadhaar
- UPI verification

====================================================

DOCTOR REGISTRATION

Required:
- MBBS
- Specialization certificates
- License upload
- Aadhaar verification

====================================================

6. CLIENT DASHBOARD

Premium hospital-style dashboard.

TOP SECTION:
- Welcome user
- Search healthcare services
- Emergency SOS button

FEATURE GRID:
- Caretaker
- Nurse
- Doctor
- Physiotherapy
- ICU Setup
- Elder Care
- Rehabilitation
- Home Injection
- Medical Equipment

LIVE MAP:
Nearby healthcare staff

BOOKING FLOW:
- Select service
- Select staff
- Select time
- Confirm booking

PAYMENT:
- UPI
- Card
- Net Banking

NO CASH OPTION

SHOW:
- Booking history
- Live tracking
- Estimated arrival time
- Chat and call
- Notifications

BOTTOM NAVIGATION:
- Home
- Bookings
- Chat
- Notifications
- Profile

====================================================

7. CARETAKER DASHBOARD

TOP:
Welcome Caretaker

FEATURES:
- Duty requests
- Accept/reject duty
- Patient details
- Live navigation
- Attendance tracking
- Earnings
- Withdrawal
- Ratings

STATUS:
Available
Busy
Offline

====================================================

8. NURSE DASHBOARD

FEATURES:
- Assigned patients
- Shift timing
- Medical tasks
- Reports
- Earnings
- Withdrawal
- Notifications

====================================================

9. DOCTOR DASHBOARD

FEATURES:
- Online consultation
- Video call
- Reports
- Prescription upload
- Appointment management
- Earnings

====================================================

10. CHAT SYSTEM

Create modern healthcare chat UI:

Client ↔ Caretaker
Client ↔ Nurse
Client ↔ Doctor

Include:
- Text message
- Voice call
- Video call button

====================================================

11. NOTIFICATION SYSTEM

Notifications:
- Booking confirmed
- Staff assigned
- Payment success
- Emergency alert
- Duty reminder

====================================================

12. BOOKING STATUS SYSTEM

Statuses:
- Pending
- Accepted
- On The Way
- Completed
- Cancelled

====================================================

13. REVIEW & RATING SYSTEM

Client can:
- Rate service
- Write review
- Give stars

====================================================

14. PROFILE SETTINGS

All users can:
- Edit profile
- Change password
- Update bank details
- Logout

====================================================

15. COMPANY ADMIN PANEL

Founder only access

Founder:
Bittu Yadav

FEATURES:
- Total users
- Total bookings
- Total earnings
- Company profit analytics
- 23% company margin
- Staff approval
- Document verification
- Emergency control
- Notification control
- System analytics

====================================================

16. COMPANY PROFIT PANEL

Show:
Booking Amount

Company Profit:
23%

Staff Earning:
77%

Show:
- Daily profit
- Weekly profit
- Monthly profit
- Withdrawal history

BUTTON:
Withdraw Profit

====================================================

17. DOCUMENT VERIFICATION PANEL

Statuses:
- Pending
- Verified
- Rejected

For:
- Caretaker
- Nurse
- Doctor

====================================================

18. FOUNDER PROFILE

PHOTO SECTION

Name:
Bittu Yadav

Role:
Founder & CEO — HHCS

Phone:
+91 9430535047

Email:
bittukumaryadav911765@gmail.com

Username:
YADAV_BITTU_BR25

Mission:
Providing trusted healthcare service at home.

Message:
Service, trust, safety, and humanity.

QUOTE:
SEVA PARMO DHARMAH
DHARMO RAKSHATI RAKSHATAH

BUTTON:
Contact Founder

====================================================

19. WEBSITE DESIGN

Responsive website design with:

HEADER:
- Logo
- Home
- Services
- About
- Contact
- Login
- Register

HERO SECTION:
Professional healthcare at your doorstep

BUTTONS:
- Book Now
- Become Caretaker

SERVICES SECTION:
- Caretaker
- Nurse
- Doctor
- Physiotherapy
- Elder Care
- Rehabilitation

WHY CHOOSE US:
- Verified staff
- OTP security
- Online payment
- 24x7 support

TESTIMONIALS SECTION

FOUNDER SECTION

FOOTER:
- Privacy Policy
- Terms & Conditions
- Contact
- Emergency support

====================================================

20. EXTRA UI ELEMENTS

Create:
- Loading screens
- Success popup
- Error popup
- Payment success screen
- Booking confirmation screen
- Empty state design
- Medical illustrations

====================================================

21. UI EXPERIENCE RULES

The UI must feel:
- Calm
- Safe
- Comfortable
- Emotional
- Trusted
- Premium
- Modern healthcare startup

Avoid:
- Cluttered UI
- Dark aggressive colors
- Gaming style interface

====================================================

22. TECH REQUIREMENTS

Create:
- Mobile app UI
- Responsive website UI
- Chrome-compatible layout
- Consistent design system
- Future-ready development structure

====================================================

Generate all screens connected with smooth navigation and premium healthcare startup appearance.