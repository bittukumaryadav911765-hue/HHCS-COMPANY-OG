
  # Home Health Care Platform

  This is a code bundle for Home Health Care Platform. The original project is available at https://www.figma.com/design/owpkxXXvGX03KvfujHeabB/Home-Health-Care-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  